# Akai Avatar Routine 2.0

Versão reorganizada para publicação:

- `extension_chromium/`: Vivaldi, Chrome, Edge e outros Chromium. Funciona 100% sem bridge local usando uma pasta autorizada pelo navegador.
- `extension_firefox/`: Zen/Firefox. Usa importação manual de imagens. O bridge local é opcional.
- `local_bridge_optional/`: bridge antigo, apenas para quem quiser usar pasta local persistente no Firefox/Zen.

## Direto significa direto

No modo **Direto, sem abrir guia**, a extensão não abre guia, não usa fallback visual e não pede aprovação manual. Se a Steam recusar, o erro aparece no histórico.

## Preview

O preview da próxima imagem é atualizado automaticamente no popup e no dashboard.


## 2.1.0 - Failed to fetch / modo direto

Esta versão adiciona correção para `Failed to fetch` na verificação Steam e melhora o modo direto sem abrir guia nova. Remova e instale de novo por causa da permissão `cookies`.


## Correções 2.1.2
- Modo de envio não volta mais para Guia visível enquanto você edita.
- Rotina salva automaticamente e não reseta antes de clicar em salvar.
- Preview/avatar da Steam no topo usa cache-bust e atualiza após envio.
- Dashboard não sobrescreve campos enquanto você está mexendo neles.
