"""
Akai Avatar Routine Bridge
Servidor local seguro para rotinas de upload de avatar via extensão privada.

Fluxo:
1) O servidor agenda comandos de upload de avatar.
2) A extensão privada faz polling em http://127.0.0.1:8765.
3) Quando houver comando, a extensão abre a página de avatar da Steam no navegador logado.
4) A extensão busca a próxima imagem pelo endpoint local e injeta no campo de upload.

Não exporta cookies, não lê senhas e não envia nada para nuvem.
"""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import random
import threading
import time
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
AVATAR_DIR = APP_DIR / "avatars"
CONFIG_PATH = APP_DIR / "config.json"
ROUTINES_PATH = APP_DIR / "routines.json"
QUEUE_PATH = DATA_DIR / "commands.json"
HISTORY_PATH = DATA_DIR / "history.jsonl"

DEFAULT_CONFIG = {
    "host": "127.0.0.1",
    "port": 8765,
    "token": "troque-este-token-local",
    "avatar_source": {
        "mode": "local_folder",
        "folder": str(AVATAR_DIR),
        "shuffle": True,
        "extensions": [".png", ".jpg", ".jpeg", ".webp", ".gif"]
    },
    "steam": {
        "avatar_url": "https://steamcommunity.com/my/edit/avatar",
        "auto_submit": False,
        "upload_mode": "visible_tab",
        "open_tab_active": True,
        "close_tab_after_success": True,
        "direct_request": {
            "enabled": False,
            "upload_url": "https://steamcommunity.com/actions/FileUploader",
            "file_field": "avatar",
            "extra_fields": {
                "type": "player_avatar_image",
                "json": "1"
            },
            "fallback_mode": "visible_tab"
        }
    }
}

DEFAULT_ROUTINES = {
    "enabled": True,
    "routines": [
        {
            "id": "steam-avatar-a-cada-60-min",
            "title": "Steam avatar — 60 min",
            "enabled": False,
            "type": "steam_avatar_upload",
            "interval_minutes": 60,
            "last_run_ts": 0,
            "upload_mode": "direct_request",
            "auto_submit": True,
            "notes": "Troca o avatar da Steam usando a pasta de avatares configurada."
        },
        {
            "id": "download-exemplo",
            "title": "Download exemplo",
            "enabled": False,
            "type": "browser_download_url",
            "interval_minutes": 1440,
            "last_run_ts": 0,
            "url": "",
            "save_as": False,
            "notes": "Baixa uma URL pelo navegador quando ativado."
        },
        {
            "id": "upload-pagina-exemplo",
            "title": "Upload página exemplo",
            "enabled": False,
            "type": "browser_open_upload",
            "interval_minutes": 1440,
            "last_run_ts": 0,
            "target_url": "",
            "notes": "Abre uma página de upload pelo navegador logado."
        }
    ]
}

_state_lock = threading.RLock()
_commands: list[dict[str, Any]] = []
_last_avatar_index = -1
_preview_avatar_path: str | None = None


def ensure_files() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    AVATAR_DIR.mkdir(exist_ok=True)
    if not CONFIG_PATH.exists():
        CONFIG_PATH.write_text(json.dumps(DEFAULT_CONFIG, indent=2, ensure_ascii=False), encoding="utf-8")
    if not ROUTINES_PATH.exists():
        ROUTINES_PATH.write_text(json.dumps(DEFAULT_ROUTINES, indent=2, ensure_ascii=False), encoding="utf-8")
    if not QUEUE_PATH.exists():
        QUEUE_PATH.write_text("[]", encoding="utf-8")


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def deep_merge(default: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for key, value in default.items():
        if isinstance(value, dict):
            merged[key] = deep_merge(value, {})
        else:
            merged[key] = value
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config() -> dict[str, Any]:
    cfg = read_json(CONFIG_PATH, DEFAULT_CONFIG)
    return deep_merge(DEFAULT_CONFIG, cfg if isinstance(cfg, dict) else {})


def save_config(cfg: dict[str, Any]) -> None:
    write_json(CONFIG_PATH, cfg)


def normalize_folder_path(folder: str) -> str:
    return str(Path(os.path.expandvars(os.path.expanduser(folder))).resolve())


def avatar_source_info() -> dict[str, Any]:
    cfg = load_config()
    src = cfg["avatar_source"]
    folder_raw = str(src.get("folder", str(AVATAR_DIR)))
    folder = Path(os.path.expandvars(os.path.expanduser(folder_raw)))
    files = list_avatar_files()
    return {
        "mode": src.get("mode", "local_folder"),
        "folder": str(folder),
        "exists": folder.exists(),
        "shuffle": bool(src.get("shuffle", True)),
        "extensions": src.get("extensions", [".png", ".jpg", ".jpeg", ".webp", ".gif"]),
        "count": len(files),
        "sample": [p.name for p in files[:20]],
    }


def update_avatar_source(data: dict[str, Any]) -> dict[str, Any]:
    global _preview_avatar_path
    cfg = load_config()
    src = cfg.setdefault("avatar_source", {})

    if "folder" in data and str(data.get("folder", "")).strip():
        src["folder"] = normalize_folder_path(str(data["folder"]).strip())
    if "shuffle" in data:
        src["shuffle"] = bool(data.get("shuffle"))
    if "extensions" in data and isinstance(data.get("extensions"), list):
        clean_exts = []
        for ext in data["extensions"]:
            ext = str(ext).strip().lower()
            if not ext:
                continue
            if not ext.startswith("."):
                ext = "." + ext
            clean_exts.append(ext)
        if clean_exts:
            src["extensions"] = sorted(set(clean_exts))

    _preview_avatar_path = None
    save_config(cfg)
    log_event({"event": "avatar_source_updated", "source": avatar_source_info()})
    return avatar_source_info()


def select_folder_dialog(initial_dir: str | None = None) -> str | None:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception as exc:
        raise RuntimeError(f"Tkinter indisponível para abrir seletor de pasta: {exc!r}") from exc

    initial = initial_dir or load_config()["avatar_source"].get("folder", str(AVATAR_DIR))
    initial = os.path.expandvars(os.path.expanduser(str(initial)))
    if not Path(initial).exists():
        initial = str(Path.home())

    root = tk.Tk()
    root.withdraw()
    try:
        root.attributes("-topmost", True)
    except Exception:
        pass
    selected = filedialog.askdirectory(
        title="Escolha a pasta de avatares para upload",
        initialdir=initial,
        mustexist=True,
        parent=root,
    )
    root.destroy()
    return selected or None


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def log_event(event: dict[str, Any]) -> None:
    event = {"ts": now_iso(), **event}
    with HISTORY_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def persist_commands() -> None:
    with _state_lock:
        write_json(QUEUE_PATH, _commands)


def load_commands() -> None:
    global _commands
    with _state_lock:
        loaded = read_json(QUEUE_PATH, [])
        _commands = loaded if isinstance(loaded, list) else []


def enqueue_command(command_type: str, payload: dict[str, Any] | None = None, source: str = "manual") -> dict[str, Any]:
    cfg = load_config()
    cmd = {
        "id": str(uuid.uuid4()),
        "type": command_type,
        "source": source,
        "created_at": now_iso(),
        "status": "pending",
        "payload": payload or {},
    }
    if command_type == "steam_avatar_upload":
        steam_cfg = cfg.get("steam", {})
        payload_in = dict(cmd.get("payload") or {})
        direct_cfg = dict(steam_cfg.get("direct_request", {}) or {})
        merged_payload = {
            "avatar_url": steam_cfg.get("avatar_url", "https://steamcommunity.com/my/edit/avatar"),
            "auto_submit": bool(steam_cfg.get("auto_submit", False)),
            "upload_mode": str(steam_cfg.get("upload_mode", "visible_tab")),
            "open_tab_active": bool(steam_cfg.get("open_tab_active", True)),
            "close_tab_after_success": bool(steam_cfg.get("close_tab_after_success", True)),
            "direct_request": direct_cfg,
            **payload_in,
        }
        # UX: quando o usuário escolhe "Direto", ele espera envio automático.
        # Então o comando direto força auto_submit e libera direct_request só para esta execução,
        # mesmo que a configuração global esteja manual/desligada.
        if merged_payload.get("upload_mode") == "direct_request":
            merged_payload["auto_submit"] = True
            direct_cfg = dict(merged_payload.get("direct_request", {}) or {})
            direct_cfg["enabled"] = True
            merged_payload["direct_request"] = direct_cfg
        cmd["payload"] = merged_payload
    with _state_lock:
        _commands.append(cmd)
        persist_commands()
    log_event({"event": "enqueue", "command_id": cmd["id"], "type": command_type, "source": source})
    return cmd


def pop_next_command() -> dict[str, Any] | None:
    with _state_lock:
        for cmd in _commands:
            if cmd.get("status") == "pending":
                cmd["status"] = "claimed"
                cmd["claimed_at"] = now_iso()
                persist_commands()
                return cmd
    return None


def set_command_status(command_id: str, status: str, detail: dict[str, Any] | None = None) -> bool:
    with _state_lock:
        for cmd in _commands:
            if cmd.get("id") == command_id:
                cmd["status"] = status
                cmd["updated_at"] = now_iso()
                if detail is not None:
                    cmd["detail"] = detail
                persist_commands()
                log_event({"event": "command_status", "command_id": command_id, "status": status, "detail": detail or {}})
                return True
    return False


def list_avatar_files() -> list[Path]:
    cfg = load_config()
    src = cfg["avatar_source"]
    folder = Path(os.path.expandvars(os.path.expanduser(src.get("folder", str(AVATAR_DIR)))))
    exts = {e.lower() for e in src.get("extensions", [".png", ".jpg", ".jpeg", ".webp", ".gif"])}
    if not folder.exists():
        return []
    files = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in exts]
    return sorted(files, key=lambda p: p.name.lower())


def next_avatar_file() -> Path | None:
    global _last_avatar_index
    files = list_avatar_files()
    if not files:
        return None
    cfg = load_config()
    if cfg["avatar_source"].get("shuffle", True):
        return random.choice(files)
    with _state_lock:
        _last_avatar_index = (_last_avatar_index + 1) % len(files)
        return files[_last_avatar_index]


def file_payload(file_path: Path) -> dict[str, Any]:
    mime = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
    raw = file_path.read_bytes()
    b64 = base64.b64encode(raw).decode("ascii")
    return {
        "filename": file_path.name,
        "mime": mime,
        "size": len(raw),
        "data_url": f"data:{mime};base64,{b64}",
    }


def preview_avatar_file() -> Path | None:
    global _preview_avatar_path
    with _state_lock:
        if _preview_avatar_path:
            existing = Path(_preview_avatar_path)
            if existing.exists():
                return existing
            _preview_avatar_path = None
        chosen = next_avatar_file()
        if chosen is None:
            return None
        _preview_avatar_path = str(chosen)
        return chosen


def avatar_preview_payload() -> dict[str, Any] | None:
    file_path = preview_avatar_file()
    if file_path is None:
        return None
    payload = file_payload(file_path)
    payload["reserved"] = True
    return payload


def avatar_payload() -> dict[str, Any] | None:
    global _preview_avatar_path
    with _state_lock:
        if _preview_avatar_path:
            file_path = Path(_preview_avatar_path)
            _preview_avatar_path = None
            if not file_path.exists():
                file_path = next_avatar_file()
        else:
            file_path = next_avatar_file()
    if file_path is None:
        return None
    return file_payload(file_path)


def update_steam_config(data: dict[str, Any]) -> dict[str, Any]:
    cfg = load_config()
    current = cfg.setdefault("steam", {})
    incoming = data.get("steam", data) if isinstance(data, dict) else {}
    if not isinstance(incoming, dict):
        incoming = {}

    valid_modes = {"visible_tab", "background_tab", "direct_request"}
    if "avatar_url" in incoming and str(incoming.get("avatar_url", "")).strip():
        current["avatar_url"] = str(incoming["avatar_url"]).strip()
    if "auto_submit" in incoming:
        current["auto_submit"] = bool(incoming.get("auto_submit"))
    if "upload_mode" in incoming and incoming.get("upload_mode") in valid_modes:
        current["upload_mode"] = incoming["upload_mode"]
        current["open_tab_active"] = incoming["upload_mode"] == "visible_tab"
    if "close_tab_after_success" in incoming:
        current["close_tab_after_success"] = bool(incoming.get("close_tab_after_success"))

    direct_in = incoming.get("direct_request")
    if isinstance(direct_in, dict):
        direct = current.setdefault("direct_request", {})
        if "enabled" in direct_in:
            direct["enabled"] = bool(direct_in.get("enabled"))
        if "upload_url" in direct_in and str(direct_in.get("upload_url", "")).strip():
            direct["upload_url"] = str(direct_in["upload_url"]).strip()
        if "file_field" in direct_in and str(direct_in.get("file_field", "")).strip():
            direct["file_field"] = str(direct_in["file_field"]).strip()
        if direct_in.get("fallback_mode") in {"visible_tab", "background_tab"}:
            direct["fallback_mode"] = direct_in["fallback_mode"]
        if isinstance(direct_in.get("extra_fields"), dict):
            direct["extra_fields"] = direct_in["extra_fields"]

    save_config(cfg)
    log_event({"event": "steam_config_updated", "steam": current})
    return current


def update_routines_doc(data: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Documento de rotinas inválido")
    doc = {
        "enabled": bool(data.get("enabled", True)),
        "routines": []
    }
    routines = data.get("routines", [])
    if not isinstance(routines, list):
        raise ValueError("Campo routines precisa ser uma lista")
    valid_modes = {"visible_tab", "background_tab", "direct_request"}
    valid_types = {"steam_avatar_upload", "browser_download_url", "browser_open_upload"}
    seen_ids: set[str] = set()
    for item in routines:
        if not isinstance(item, dict):
            continue
        r = dict(item)
        rid = str(r.get("id") or f"routine-{uuid.uuid4()}").strip()
        if rid in seen_ids:
            rid = f"{rid}-{str(uuid.uuid4())[:8]}"
        seen_ids.add(rid)
        r["id"] = rid
        r["title"] = str(r.get("title") or r.get("name") or rid).strip()[:80]
        r["type"] = str(r.get("type") or "steam_avatar_upload")
        if r["type"] not in valid_types:
            r["type"] = "steam_avatar_upload"
        r["enabled"] = bool(r.get("enabled", False))
        try:
            r["interval_minutes"] = max(1, int(r.get("interval_minutes", 60)))
        except Exception:
            r["interval_minutes"] = 60
        try:
            r["last_run_ts"] = float(r.get("last_run_ts", 0) or 0)
        except Exception:
            r["last_run_ts"] = 0
        if r.get("upload_mode") not in valid_modes:
            r.pop("upload_mode", None)
        if "auto_submit" in r:
            r["auto_submit"] = bool(r.get("auto_submit"))
        if "save_as" in r:
            r["save_as"] = bool(r.get("save_as"))
        for key in ("url", "target_url", "filename", "notes"):
            if key in r:
                r[key] = str(r.get(key) or "").strip()
        doc["routines"].append(r)
    write_json(ROUTINES_PATH, doc)
    log_event({"event": "routines_updated", "count": len(doc["routines"])})
    return doc


def command_payload_from_routine(routine: dict[str, Any]) -> tuple[str | None, dict[str, Any]]:
    rtype = str(routine.get("type") or "steam_avatar_upload")
    base = {
        "routine_id": routine.get("id"),
        "routine_title": routine.get("title") or routine.get("id"),
    }
    if rtype == "steam_avatar_upload":
        payload = dict(base)
        if routine.get("upload_mode"):
            payload["upload_mode"] = routine.get("upload_mode")
        if "auto_submit" in routine:
            payload["auto_submit"] = bool(routine.get("auto_submit"))
        return "steam_avatar_upload", payload
    if rtype == "browser_download_url":
        url = str(routine.get("url") or "").strip()
        if not url:
            return None, {**base, "error": "Rotina de download sem URL"}
        return "browser_download_url", {
            **base,
            "url": url,
            "filename": str(routine.get("filename") or "").strip(),
            "save_as": bool(routine.get("save_as", False)),
        }
    if rtype == "browser_open_upload":
        target_url = str(routine.get("target_url") or routine.get("url") or "").strip()
        if not target_url:
            return None, {**base, "error": "Rotina de upload sem URL da página"}
        return "browser_open_upload", {**base, "target_url": target_url}
    return None, {**base, "error": f"Tipo de rotina desconhecido: {rtype}"}


def enqueue_routine_now(routine_id: str, source: str = "manual-routine") -> dict[str, Any]:
    doc = read_json(ROUTINES_PATH, DEFAULT_ROUTINES)
    routines = doc.get("routines", []) if isinstance(doc, dict) else []
    for routine in routines:
        if str(routine.get("id")) == str(routine_id):
            cmd_type, payload = command_payload_from_routine(routine)
            if not cmd_type:
                raise ValueError(payload.get("error", "Rotina inválida"))
            return enqueue_command(cmd_type, payload, source=source)
    raise ValueError("Rotina não encontrada")


def toggle_routine(routine_id: str, enabled: bool | None = None) -> dict[str, Any]:
    doc = read_json(ROUTINES_PATH, DEFAULT_ROUTINES)
    routines = doc.get("routines", []) if isinstance(doc, dict) else []
    found = False
    for routine in routines:
        if str(routine.get("id")) == str(routine_id):
            routine["enabled"] = (not bool(routine.get("enabled", False))) if enabled is None else bool(enabled)
            found = True
            break
    if not found:
        raise ValueError("Rotina não encontrada")
    write_json(ROUTINES_PATH, doc)
    log_event({"event": "routine_toggle", "routine_id": routine_id, "enabled": enabled})
    return doc


class Handler(BaseHTTPRequestHandler):
    server_version = "AkaiAvatarBridge/1.5"

    def _clean_path(self) -> str:
        parsed = urlparse(self.path)
        parts = [part for part in parsed.path.split("/") if part]
        return "/" + "/".join(parts) if parts else "/"

    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Akai-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        super().end_headers()

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.end_headers()

    def _send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def _authorized(self) -> bool:
        cfg = load_config()
        token = cfg.get("token", "")
        given = self.headers.get("X-Akai-Token", "")
        return bool(token) and given == token

    def _need_auth(self) -> bool:
        if self._clean_path() in {"/health", "/api/health", "/api/status"}:
            return False
        return not self._authorized()

    def do_GET(self) -> None:
        path = self._clean_path()
        if self._need_auth():
            self._send_json({"ok": False, "error": "Token local inválido"}, 401)
            return

        if path in {"/health", "/api/health", "/api/status"}:
            cfg = load_config()
            self._send_json({
                "ok": True,
                "app": "Akai Avatar Routine Bridge",
                "version": "1.5-multi-routines",
                "time": now_iso(),
                "host": cfg.get("host"),
                "port": cfg.get("port"),
            })
            return

        if path == "/api/commands/next":
            cmd = pop_next_command()
            self._send_json({"ok": True, "command": cmd})
            return

        if path == "/api/avatar/next":
            payload = avatar_payload()
            if payload is None:
                self._send_json({"ok": False, "error": "Nenhuma imagem encontrada na pasta de avatares"}, 404)
                return
            self._send_json({"ok": True, "avatar": payload})
            return

        if path in {"/api/avatar/preview", "/api/avatar/peek", "/api/avatars/preview"}:
            payload = avatar_preview_payload()
            if payload is None:
                self._send_json({"ok": False, "error": "Nenhuma imagem encontrada na pasta de avatares"}, 404)
                return
            self._send_json({"ok": True, "avatar": payload})
            return

        if path in {"/api/avatar/source", "/api/avatars/source", "/api/avatar/folder", "/api/folder"}:
            self._send_json({"ok": True, "source": avatar_source_info()})
            return

        if path in {"/api/avatar/list", "/api/avatars", "/api/images"}:
            files = list_avatar_files()
            self._send_json({"ok": True, "count": len(files), "files": [p.name for p in files[:500]], "source": avatar_source_info()})
            return

        if path in {"/api/config", "/api/settings"}:
            cfg = load_config()
            safe = json.loads(json.dumps(cfg))
            safe["token"] = "***"
            self._send_json({"ok": True, "config": safe, "settings": safe})
            return

        if path in {"/api/config/steam", "/api/steam/config"}:
            cfg = load_config()
            self._send_json({"ok": True, "steam": cfg.get("steam", {})})
            return

        if path in {"/api/routines", "/api/routine"}:
            self._send_json({"ok": True, "routines": read_json(ROUTINES_PATH, DEFAULT_ROUTINES)})
            return

        if path in {"/api/commands", "/api/queue"}:
            with _state_lock:
                self._send_json({"ok": True, "commands": _commands})
            return

        if path in {"/api/history", "/api/logs"}:
            try:
                lines = HISTORY_PATH.read_text(encoding="utf-8").splitlines()[-200:] if HISTORY_PATH.exists() else []
                self._send_json({"ok": True, "lines": lines})
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 500)
            return

        self._send_json({"ok": False, "error": "Endpoint não encontrado"}, 404)

    def do_POST(self) -> None:
        path = self._clean_path()
        if self._need_auth():
            self._send_json({"ok": False, "error": "Token local inválido"}, 401)
            return
        body = self._read_json_body()

        if path in {"/api/steam/avatar/run", "/api/avatar/run", "/api/upload/steam-avatar"}:
            cmd = enqueue_command("steam_avatar_upload", body.get("payload") or {}, source=body.get("source", "manual-api"))
            self._send_json({"ok": True, "command": cmd})
            return

        if path in {"/api/avatar/source", "/api/avatars/source", "/api/avatar/folder", "/api/folder"}:
            source = update_avatar_source(body)
            self._send_json({"ok": True, "source": source})
            return

        if path in {"/api/avatar/folder/select", "/api/folder/select"}:
            try:
                selected = select_folder_dialog(body.get("initial_dir"))
                if not selected:
                    self._send_json({"ok": False, "error": "Nenhuma pasta selecionada"})
                    return
                source = update_avatar_source({"folder": selected})
                self._send_json({"ok": True, "source": source})
                return
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 500)
                return

        if path in {"/api/config/steam", "/api/steam/config"}:
            try:
                steam = update_steam_config(body)
                self._send_json({"ok": True, "steam": steam})
                return
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 400)
                return

        if path in {"/api/routines", "/api/routine"}:
            try:
                doc = update_routines_doc(body)
                self._send_json({"ok": True, "routines": doc})
                return
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 400)
                return

        if path in {"/api/routines/run", "/api/routine/run"}:
            try:
                cmd = enqueue_routine_now(str(body.get("routine_id") or body.get("id") or ""), source=body.get("source", "manual-routine"))
                self._send_json({"ok": True, "command": cmd})
                return
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 400)
                return

        if path in {"/api/routines/toggle", "/api/routine/toggle"}:
            try:
                doc = toggle_routine(str(body.get("routine_id") or body.get("id") or ""), body.get("enabled") if "enabled" in body else None)
                self._send_json({"ok": True, "routines": doc})
                return
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 400)
                return

        if path in {"/api/commands/status", "/api/queue/status"}:
            command_id = str(body.get("command_id", ""))
            status = str(body.get("status", ""))
            if not command_id or status not in {"pending", "claimed", "done", "failed", "skipped"}:
                self._send_json({"ok": False, "error": "command_id/status inválidos"}, 400)
                return
            ok = set_command_status(command_id, status, body.get("detail") or {})
            self._send_json({"ok": ok})
            return

        if path == "/api/tab/send":
            log_event({"event": "tab", "data": body})
            self._send_json({"ok": True})
            return

        self._send_json({"ok": False, "error": "Endpoint não encontrado"}, 404)

    def log_message(self, format: str, *args: Any) -> None:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {self.address_string()} {format % args}")


def scheduler_loop() -> None:
    while True:
        try:
            routines_doc = read_json(ROUTINES_PATH, DEFAULT_ROUTINES)
            if routines_doc.get("enabled", True):
                changed = False
                now_ts = time.time()
                for routine in routines_doc.get("routines", []):
                    if not routine.get("enabled", False):
                        continue
                    rtype = routine.get("type")
                    interval = max(1, int(routine.get("interval_minutes", 60)))
                    last = float(routine.get("last_run_ts", 0) or 0)
                    if now_ts - last >= interval * 60:
                        cmd_type, payload = command_payload_from_routine(routine)
                        if cmd_type:
                            enqueue_command(cmd_type, payload, source="scheduler")
                        else:
                            log_event({"event": "routine_skipped", "routine_id": routine.get("id"), "detail": payload})
                        routine["last_run_ts"] = now_ts
                        changed = True
                if changed:
                    write_json(ROUTINES_PATH, routines_doc)
        except Exception as exc:
            log_event({"event": "scheduler_error", "error": repr(exc)})
        time.sleep(15)


def main() -> None:
    ensure_files()
    load_commands()
    cfg = load_config()
    host = cfg.get("host", "127.0.0.1")
    port = int(cfg.get("port", 8765))
    threading.Thread(target=scheduler_loop, daemon=True).start()
    print("Akai Avatar Routine Bridge")
    print(f"Local: http://{host}:{port}")
    print(f"Config: {CONFIG_PATH}")
    print(f"Rotinas: {ROUTINES_PATH}")
    print(f"Avatares: {load_config()['avatar_source']['folder']}")
    print("Mantenha aberto enquanto usar a extensão.")
    server = ThreadingHTTPServer((host, port), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Encerrando...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
