@echo off
cd /d "%~dp0"
python bridge_server.py
pause
