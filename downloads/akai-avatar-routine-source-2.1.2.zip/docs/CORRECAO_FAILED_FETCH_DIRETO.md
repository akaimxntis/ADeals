# Correção 2.1.0

- Corrige `Failed to fetch` na verificação Steam usando guia Steam já aberta/cookies como fallback.
- Modo Direto continua sem abrir guia nova.
- Modo Direto agora tenta enviar pelo contexto de uma guia Steam existente para evitar bloqueio/CORS do service worker.
- Adicionada permissão `cookies`, então remova e instale a extensão de novo.

Importante: para o modo direto funcionar com mais chance, deixe qualquer página da Steam aberta e logada. Ele não abre uma guia nova sozinho.
