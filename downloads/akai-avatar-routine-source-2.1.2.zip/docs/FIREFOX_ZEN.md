# Firefox/Zen

Firefox/Zen não tem o mesmo fluxo persistente de pasta local do Chromium.

## Modo padrão

1. Instale/carregue `extension_firefox`.
2. Abra o dashboard.
3. Selecione várias imagens no campo de importação manual.
4. Clique em **Importar imagens escolhidas**.
5. Use as rotinas normalmente.

## Bridge opcional

Use `local_bridge_optional/run_bridge.bat` só se quiser usar uma pasta local persistente no Firefox/Zen.
No dashboard, marque **Usar bridge local opcional** e teste a conexão.
