# Correções desta versão

- Chromium/Vivaldi: sem bridge local obrigatório.
- Firefox/Zen: importação manual de imagens, com bridge opcional.
- Modo direto não abre guia em nenhuma hipótese.
- Modo direto força envio automático, sem etapa manual.
- Preview do topo do dashboard atualiza automaticamente como o popup.
- Histórico usa cards legíveis e atualiza em tempo real.
