# Chromium/Vivaldi sem bridge

1. Instale/carregue `extension_chromium`.
2. O dashboard abre automaticamente.
3. Clique em **Escolher pasta local**.
4. Escolha a pasta de avatares.
5. Clique em **Verificar Steam**.
6. Teste primeiro com **Guia visível**.
7. Para modo direto, selecione **Direto, sem abrir guia**.

A pasta é autorizada pelo navegador via File System Access API. A extensão não precisa de `run_bridge.bat`, Python ou servidor localhost.
