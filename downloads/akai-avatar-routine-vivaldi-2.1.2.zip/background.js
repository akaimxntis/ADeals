/* Akai Avatar Routine 2.0 - Chromium: sem bridge local obrigatório */
const DEFAULTS = {
  uploadMode: "visible_tab",
  autoSubmit: false,
  shuffle: true,
  avatarMode: "folder",
  reservedAvatarName: null,
  usedAvatarNames: [],
  routine: { enabled: false, intervalMinutes: 60, lastRunTs: 0 },
  direct: { enabled: true, uploadUrl: "https://steamcommunity.com/actions/FileUploader", fileField: "avatar" },
  bridge: { enabled: false, baseUrl: "http://127.0.0.1:8765", token: "troque-este-token-local" },
  logs: []
};
const VALID_MODES = new Set(["visible_tab", "background_tab", "direct_request"]);
const DB_NAME = "akai-avatar-routine-db";
const DB_VERSION = 2;
const IMAGE_EXT = /\.(png|jpe?g|gif|webp)$/i;
const MAX_LOGS = 120;
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function isFirefox(){return typeof browser !== "undefined" && typeof chrome.scripting === "undefined";}
function apiLastError(){return chrome.runtime && chrome.runtime.lastError ? chrome.runtime.lastError.message : null;}
function storageGet(defaults){return new Promise(resolve=>chrome.storage.local.get(defaults, resolve));}
function storageSet(obj){return new Promise((resolve,reject)=>chrome.storage.local.set(obj,()=>{const e=apiLastError();e?reject(new Error(e)):resolve();}));}
function tabsCreate(opts){if(typeof browser!=="undefined"&&browser.tabs&&browser.tabs.create)return browser.tabs.create(opts);return new Promise((resolve,reject)=>chrome.tabs.create(opts,t=>{const e=apiLastError();e?reject(new Error(e)):resolve(t);}));}
function tabsUpdate(tabId,opts){if(typeof browser!=="undefined"&&browser.tabs&&browser.tabs.update)return browser.tabs.update(tabId,opts);return new Promise((resolve,reject)=>chrome.tabs.update(tabId,opts,t=>{const e=apiLastError();e?reject(new Error(e)):resolve(t);}));}
function tabsRemove(tabId){if(typeof browser!=="undefined"&&browser.tabs&&browser.tabs.remove)return browser.tabs.remove(tabId);return new Promise((resolve,reject)=>chrome.tabs.remove(tabId,()=>{const e=apiLastError();e?reject(new Error(e)):resolve(true);}));}
function tabsSendMessage(tabId,msg){if(typeof browser!=="undefined"&&browser.tabs&&browser.tabs.sendMessage)return browser.tabs.sendMessage(tabId,msg);return new Promise((resolve,reject)=>chrome.tabs.sendMessage(tabId,msg,r=>{const e=apiLastError();e?reject(new Error(e)):resolve(r);}));}
function executeScriptFile(tabId,file){if(chrome.scripting&&chrome.scripting.executeScript)return chrome.scripting.executeScript({target:{tabId},files:[file]});if(typeof browser!=="undefined"&&browser.tabs&&browser.tabs.executeScript)return browser.tabs.executeScript(tabId,{file});return new Promise((resolve,reject)=>chrome.tabs.executeScript(tabId,{file},r=>{const e=apiLastError();e?reject(new Error(e)):resolve(r);}));}
function runtimeUrl(path){return chrome.runtime.getURL(path);}
function openDb(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains("handles"))db.createObjectStore("handles");if(!db.objectStoreNames.contains("manualFiles"))db.createObjectStore("manualFiles",{keyPath:"name"});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error("IndexedDB falhou"));});}
async function idbGet(store,key){const db=await openDb();return new Promise((resolve,reject)=>{const tx=db.transaction(store,"readonly");const req=tx.objectStore(store).get(key);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);tx.oncomplete=()=>db.close();});}
async function idbGetAll(store){const db=await openDb();return new Promise((resolve,reject)=>{const tx=db.transaction(store,"readonly");const req=tx.objectStore(store).getAll();req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error);tx.oncomplete=()=>db.close();});}
async function getState(){const s=await storageGet(DEFAULTS);if(!VALID_MODES.has(s.uploadMode))s.uploadMode=DEFAULTS.uploadMode;if(!s.routine)s.routine=DEFAULTS.routine;if(!s.direct)s.direct=DEFAULTS.direct;if(!s.bridge)s.bridge=DEFAULTS.bridge;if(!Array.isArray(s.usedAvatarNames))s.usedAvatarNames=[];if(!Array.isArray(s.logs))s.logs=[];return s;}
async function addLog(entry){const s=await getState();const log={id:`log-${Date.now()}-${Math.random().toString(16).slice(2)}`,ts:new Date().toISOString(),...entry};const logs=[log,...(s.logs||[])].slice(0,MAX_LOGS);await storageSet({logs});try{chrome.runtime.sendMessage({type:"AKAI_LOGS_CHANGED"});}catch(_){}return log;}
function imageInfoFromFile(file){return {name:file.name,filename:file.name,size:file.size,mime:file.type||mimeFromName(file.name)};}
function mimeFromName(name){const n=String(name||"").toLowerCase();if(n.endsWith(".png"))return"image/png";if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return"image/jpeg";if(n.endsWith(".webp"))return"image/webp";if(n.endsWith(".gif"))return"image/gif";return"application/octet-stream";}
function fileToDataUrl(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error("Falha lendo imagem"));r.readAsDataURL(file);});}
async function getDirectoryHandle(){const item=await idbGet("handles","avatarDirectory");return item&&item.handle?item.handle:null;}
async function listFolderFiles(){const handle=await getDirectoryHandle();if(!handle)return {ok:false,error:"Nenhuma pasta autorizada. Abra o dashboard e escolha uma pasta.",files:[],mode:"folder"};if(handle.queryPermission){const perm=await handle.queryPermission({mode:"read"});if(perm!=="granted")return {ok:false,error:"Permissão da pasta expirou. Escolha a pasta de novo no dashboard.",files:[],mode:"folder",permission:perm};}
const files=[];for await(const [name,entry] of handle.entries()){if(entry.kind==="file"&&IMAGE_EXT.test(name)){files.push({name,filename:name,handle:entry,mime:mimeFromName(name)});}}
files.sort((a,b)=>a.name.localeCompare(b.name,"pt-BR",{numeric:true}));return {ok:true,files,mode:"folder",folderName:handle.name||"Pasta"};}
async function listManualFiles(){const rows=await idbGetAll("manualFiles");const files=rows.filter(x=>x&&x.blob&&IMAGE_EXT.test(x.name)).map(x=>({name:x.name,filename:x.name,size:x.size,mime:x.type||mimeFromName(x.name),manual:x}));files.sort((a,b)=>a.name.localeCompare(b.name,"pt-BR",{numeric:true}));return {ok:true,files,mode:"manual",folderName:"Importação manual"};}
async function bridgeApi(path,options={}){const s=await getState();const base=String(s.bridge.baseUrl||DEFAULTS.bridge.baseUrl).replace(/\/+$/,"");const clean=String(path).startsWith("/")?path:`/${path}`;const headers={"X-Akai-Token":s.bridge.token||DEFAULTS.bridge.token,...(options.headers||{})};if(options.body&&!headers["Content-Type"]&&!(options.body instanceof FormData))headers["Content-Type"]="application/json";const res=await fetch(base+clean,{...options,headers});const text=await res.text();let json;try{json=JSON.parse(text);}catch{json={ok:false,raw:text};}if(!res.ok)throw new Error((json&&json.error)||json.raw||`HTTP ${res.status}`);return json;}
async function listAvatarFiles(){const s=await getState();if(s.avatarMode==="bridge")return {ok:true,files:[],mode:"bridge",folderName:"Bridge opcional"};if(s.avatarMode==="manual")return listManualFiles();return listFolderFiles();}
async function getFileByName(name){const s=await getState();if(s.avatarMode==="manual"){const rows=await idbGetAll("manualFiles");const row=rows.find(x=>x.name===name);if(!row)throw new Error("Imagem importada não encontrada");return new File([row.blob],row.name,{type:row.type||mimeFromName(row.name),lastModified:row.lastModified||Date.now()});}
const handle=await getDirectoryHandle();if(!handle)throw new Error("Pasta não autorizada");const fh=await handle.getFileHandle(name);return fh.getFile();}
function chooseName(files,state){if(!files.length)return null;if(state.reservedAvatarName&&files.some(f=>f.name===state.reservedAvatarName))return state.reservedAvatarName;let used=new Set(state.usedAvatarNames||[]);let candidates=files.filter(f=>!used.has(f.name));if(!candidates.length)candidates=files;if(state.shuffle){return candidates[Math.floor(Math.random()*candidates.length)].name;}return candidates[0].name;}
async function getAvatarPreview(forceNew=false){const s=await getState();if(s.avatarMode==="bridge"){try{return await bridgeApi("/api/avatar/preview");}catch(err){return {ok:false,error:String(err.message||err),mode:"bridge"};}}
const listing=await listAvatarFiles();if(!listing.ok)return listing;if(!listing.files.length)return {ok:false,error:"Nenhuma imagem encontrada.",mode:listing.mode};let name=forceNew?null:s.reservedAvatarName;if(!name||!listing.files.some(f=>f.name===name)){name=chooseName(listing.files,{...s,reservedAvatarName:null});await storageSet({reservedAvatarName:name});}
const file=await getFileByName(name);const data_url=await fileToDataUrl(file);return {ok:true,mode:listing.mode,folderName:listing.folderName,count:listing.files.length,examples:listing.files.slice(0,6).map(f=>f.name),avatar:{...imageInfoFromFile(file),data_url}};}
async function getNextAvatar(){const s=await getState();if(s.avatarMode==="bridge"){const resp=await bridgeApi("/api/avatar/next");if(!resp.ok||!resp.avatar)throw new Error(resp.error||"Bridge não retornou avatar");return {avatar:resp.avatar,source:"bridge"};}
const preview=await getAvatarPreview(false);if(!preview.ok||!preview.avatar)throw new Error(preview.error||"Nenhum avatar disponível");return {avatar:preview.avatar,source:preview.mode};}
async function markAvatarUsed(name){if(!name)return;const s=await getState();let used=Array.isArray(s.usedAvatarNames)?s.usedAvatarNames.slice():[];if(!used.includes(name))used.push(name);await storageSet({usedAvatarNames:used.slice(-500),reservedAvatarName:null,lastUploadedName:name});}
async function getAvatarSource(){const s=await getState();if(s.avatarMode==="bridge"){try{const src=await bridgeApi("/api/avatar/source");return {...src,avatarMode:"bridge",bridge:true};}catch(err){return {ok:false,avatarMode:"bridge",bridge:true,error:String(err.message||err)};}}
const listing=await listAvatarFiles();return {...listing,avatarMode:s.avatarMode,count:listing.files?listing.files.length:0,examples:listing.files?listing.files.slice(0,8).map(f=>f.name):[]};}
function decodeHtmlEntities(value){return String(value||"").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&#39;|&#x27;/g,"'");}
function firstMatch(html,patterns){for(const re of patterns){const m=String(html||"").match(re);if(m&&m[1])return decodeHtmlEntities(m[1].trim());}return null;}
function extractSessionId(html){return firstMatch(html,[/g_sessionID\s*=\s*["']([^"']+)["']/i,/name=["']sessionid["'][^>]*value=["']([^"']+)["']/i,/sessionid["']?\s*[:=]\s*["']([^"']+)["']/i]);}
function extractSteamId(html,url=""){const patterns=[/name=["']sId["'][^>]*value=["'](\d{15,20})["']/i,/g_steamID\s*=\s*["'](\d{15,20})["']/i,/["']steamid["']\s*:\s*["'](\d{15,20})["']/i,/\/profiles\/(\d{15,20})(?:\/|$)/i,/\b(7656119\d{10})\b/i];for(const v of [html||"",url||""]){for(const re of patterns){const m=String(v).match(re);if(m&&m[1])return m[1];}}return null;}
function extractPersonaName(html){const name=firstMatch(html,[/<steamID><!\[CDATA\[(.*?)\]\]><\/steamID>/i,/<span[^>]+class=["'][^"']*actual_persona_name[^"']*["'][^>]*>([^<]+)<\/span>/i,/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i,/<title>(.*?)<\/title>/i]);return name?name.replace(/\s*::\s*Steam Community\s*$/i,"").replace(/^Steam Community\s*::\s*/i,"").trim():null;}
function extractAvatarUrl(html){return firstMatch(html,[/<avatarFull><!\[CDATA\[(.*?)\]\]><\/avatarFull>/i,/<avatarMedium><!\[CDATA\[(.*?)\]\]><\/avatarMedium>/i,/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i,/<img[^>]+src=["']([^"']+avatars[^"']+)["'][^>]*>/i]);}
async function getSteamLinkStatus(){
  const failText="Não consegui verificar a Steam direto pela extensão. Abra qualquer página da Steam já logada e clique em Verificar Steam de novo.";
  try{
    const tabCtx=await getSteamContextFromExistingTab();
    if(tabCtx&&tabCtx.ok&&tabCtx.linked){
      const data={...tabCtx,ok:true,checkedAt:Date.now(),source:"steam-tab"};
      await storageSet({steamLinkCache:data});
      return data;
    }
    const cookieCtx=await getSteamContextFromCookies();
    let data={ok:true,linked:!!(cookieCtx.steamid||cookieCtx.sessionid),personaName:cookieCtx.personaName||cookieCtx.steamid||null,avatarUrl:null,profileUrl:cookieCtx.steamid?`https://steamcommunity.com/profiles/${cookieCtx.steamid}`:"https://steamcommunity.com/",steamid:cookieCtx.steamid||null,sessionidFound:!!cookieCtx.sessionid,canDirectAvatarUpload:!!(cookieCtx.steamid&&cookieCtx.sessionid),checkedAt:Date.now(),source:"cookies"};
    try{
      const profile=await fetchSteamProfileSafe(cookieCtx.steamid);
      if(profile&&profile.linked){data={...data,...profile,sessionidFound:!!cookieCtx.sessionid,canDirectAvatarUpload:!!(profile.steamid&&cookieCtx.sessionid),source:"cookies+profile"};}
    }catch(_){/* mantém fallback por cookie */}
    if(data.linked){await storageSet({steamLinkCache:data});return data;}
    data={ok:false,linked:false,error:failText,checkedAt:Date.now(),source:"none"};
    await storageSet({steamLinkCache:data});return data;
  }catch(err){
    const data={ok:false,linked:false,error:String(err&&err.message||err||failText).replace(/^TypeError:\s*/,'')||failText,checkedAt:Date.now()};
    await storageSet({steamLinkCache:data});return data;
  }
}
async function getSteamLinkCache(){const s=await storageGet({steamLinkCache:null});return s.steamLinkCache?{cached:true,...s.steamLinkCache}:{ok:true,cached:false,linked:false,error:"Ainda não verificado."};}
function cookiesGetAll(details){return new Promise(resolve=>{try{if(!chrome.cookies)return resolve([]);chrome.cookies.getAll(details,c=>resolve(c||[]));}catch(_){resolve([]);}});}
function parseSteamIdFromCookieValue(value){const decoded=decodeURIComponent(String(value||""));let m=decoded.match(/(7656119\d{10})/);return m?m[1]:null;}
async function getSteamContextFromCookies(){
  const cookies=await cookiesGetAll({domain:"steamcommunity.com"});
  const byName=Object.fromEntries(cookies.map(c=>[c.name,c.value]));
  const sessionid=byName.sessionid||null;
  const login=byName.steamLoginSecure||byName.steamLogin||byName.steamMachineAuth||"";
  const steamid=parseSteamIdFromCookieValue(login)||parseSteamIdFromCookieValue(Object.values(byName).join("|"));
  return {sessionid,steamid,personaName:null};
}
function tabsQuery(opts){if(typeof browser!=="undefined"&&browser.tabs&&browser.tabs.query)return browser.tabs.query(opts);return new Promise(resolve=>{try{chrome.tabs.query(opts,t=>resolve(t||[]));}catch(_){resolve([]);}});}
async function getExistingSteamTab(){
  let tabs=[];
  try{tabs=await tabsQuery({url:["https://steamcommunity.com/*","https://*.steamcommunity.com/*"]});}catch(_){tabs=[];}
  tabs=(tabs||[]).filter(t=>t&&t.id&&/^https:\/\/([^/]+\.)?steamcommunity\.com\//i.test(t.url||""));
  return tabs[0]||null;
}
async function ensureSteamContent(tabId){try{await executeScriptFile(tabId,"steam_avatar_content.js");return true;}catch(_){return false;}}
async function sendToExistingSteamTab(msg){const tab=await getExistingSteamTab();if(!tab)return {ok:false,error:"Nenhuma guia da Steam aberta. O modo direto não abre guia; abra a Steam uma vez e tente de novo.",code:"NO_STEAM_TAB"};await ensureSteamContent(tab.id);try{return await tabsSendMessage(tab.id,msg);}catch(err){return {ok:false,error:String(err&&err.message||err),code:"STEAM_TAB_MESSAGE_FAILED",tabId:tab.id};}}
async function getSteamContextFromExistingTab(){
  const resp=await sendToExistingSteamTab({type:"AKAI_STEAM_GET_LINK"});
  if(resp&&resp.ok)return resp;
  return null;
}
async function fetchSteamProfileSafe(steamid){
  const urls=[];
  if(steamid)urls.push(`https://steamcommunity.com/profiles/${steamid}?xml=1`);
  urls.push("https://steamcommunity.com/my?xml=1");
  for(const url of urls){
    try{
      const res=await fetch(url,{credentials:"include",cache:"no-store"});
      const xml=await res.text();
      if(!res.ok||/<response>\s*<error>|login\/home|Sign In|Join Steam/i.test(xml))continue;
      const sid=extractSteamId(xml,res.url||url)||steamid||null;
      const personaName=extractPersonaName(xml);
      const avatarUrl=extractAvatarUrl(xml);
      if(sid||personaName||avatarUrl)return {ok:true,linked:true,personaName,avatarUrl,profileUrl:res.url||url,steamid:sid};
    }catch(_){/* ignora */}
  }
  return null;
}
async function fetchSteamPageContext(){
  const cookieCtx=await getSteamContextFromCookies();
  let sessionid=cookieCtx.sessionid||null, steamid=cookieCtx.steamid||null, page={ok:false,status:0,url:"https://steamcommunity.com/my/edit/avatar",html:""};
  if(sessionid&&steamid)return {page,pages:[],sessionid,steamid,source:"cookies"};
  try{
    const tabCtx=await getSteamContextFromExistingTab();
    if(tabCtx){sessionid=sessionid||tabCtx.sessionid;steamid=steamid||tabCtx.steamid;page={ok:true,status:200,url:tabCtx.profileUrl||page.url,html:""};}
  }catch(_){/* ignora */}
  if(sessionid&&steamid)return {page,pages:[],sessionid,steamid,source:"tab/cookies"};
  const pages=[];
  for(const url of ["https://steamcommunity.com/my/edit/avatar","https://steamcommunity.com/my/","https://steamcommunity.com/my?xml=1"]){try{const res=await fetch(url,{credentials:"include",cache:"no-store"});const html=await res.text();const p={url:res.url||url,status:res.status,ok:res.ok,html};pages.push(p);if(!page.ok)page=p;sessionid=sessionid||extractSessionId(html);steamid=steamid||extractSteamId(html,p.url);}catch(_){} }
  return {page,pages,sessionid,steamid,source:"worker"};
}
function looksLikeSteamUploadError(text,parsed){const raw=String(text||"").trim();if(/^#?Error_/i.test(raw)||/BadOrMissingSteamID/i.test(raw))return true;if(/error/i.test(raw)&&/steamid|session|avatar|upload/i.test(raw))return true;if(parsed&&typeof parsed==="object"){if(parsed.success===false||parsed.success===0||parsed.error||parsed.err_msg)return true;if(/BadOrMissingSteamID|#Error_/i.test(JSON.stringify(parsed)))return true;}return false;}
function normalizeSteamUploadResponse(text){try{return JSON.parse(text);}catch{return String(text||"").slice(0,700);}}
function buildSteamUploaderUrl(uploadUrl,steamid){const url=new URL(uploadUrl||DEFAULTS.direct.uploadUrl);if(!url.searchParams.has("type"))url.searchParams.set("type","player_avatar_image");if(!url.searchParams.has("sId")&&steamid)url.searchParams.set("sId",steamid);if(!url.searchParams.has("bgColor"))url.searchParams.set("bgColor","262627");return url.toString();}
async function dataUrlToFile(dataUrl,filename,mime){const res=await fetch(dataUrl);const blob=await res.blob();return new File([blob],filename||"avatar.png",{type:mime||blob.type||"image/png"});}
async function runDirectUpload(avatar){
  const s=await getState();
  if(!s.direct.enabled)return {ok:false,mode:"direct_request",error:"Modo direto desativado."};
  // Primeiro tenta pelo contexto de uma guia Steam já aberta. Isso NÃO abre guia nova e evita o Failed to fetch/CORS do service worker.
  const tabResp=await sendToExistingSteamTab({type:"AKAI_STEAM_DIRECT_UPLOAD",avatar,direct:s.direct});
  if(tabResp&&tabResp.ok){return {...tabResp,mode:"direct_request",note:(tabResp.note||"Avatar enviado direto usando a guia Steam já aberta. Nenhuma guia nova foi aberta.")};}
  // Se não houver guia Steam aberta, ainda tenta o caminho puro via service worker/cookies.
  const context=await fetchSteamPageContext();
  const {sessionid,steamid}=context;
  if(!sessionid||!steamid){return {ok:false,mode:"direct_request",error:(tabResp&&tabResp.error)||"Modo direto precisa da Steam logada. Ele NÃO abre guia; abra qualquer página da Steam uma vez e tente de novo.",debug:{tabDirect:tabResp,sessionidFound:!!sessionid,steamidFound:!!steamid,source:context.source}};}
  try{
    const file=await dataUrlToFile(avatar.data_url,avatar.filename,avatar.mime);
    const uploadUrl=buildSteamUploaderUrl(s.direct.uploadUrl,steamid);
    const fileField=s.direct.fileField||"avatar";
    const form=new FormData();
    form.append("MAX_FILE_SIZE",String(Math.max(1048576,avatar.size||file.size||0)));
    form.append("type","player_avatar_image");
    form.append("sId",steamid);
    form.append("sessionid",sessionid);
    form.append("doSub","1");
    form.append("json","1");
    form.append(fileField,file,avatar.filename||"avatar.png");
    const uploadRes=await fetch(uploadUrl,{method:"POST",body:form,credentials:"include",cache:"no-store"});
    const text=await uploadRes.text();
    const parsed=normalizeSteamUploadResponse(text);
    const rejected=looksLikeSteamUploadError(text,typeof parsed==="object"?parsed:null);
    return {ok:uploadRes.ok&&!rejected,mode:"direct_request",filename:avatar.filename,size:avatar.size,httpStatus:uploadRes.status,steamResponse:parsed,steamid,note:uploadRes.ok&&!rejected?"Avatar enviado no modo direto. Nenhuma guia foi aberta.":"A Steam recusou o upload direto. Nenhuma guia foi aberta.",debug:{sessionidFound:!!sessionid,steamidFound:!!steamid,source:context.source,tabDirect:tabResp}};
  }catch(err){
    return {ok:false,mode:"direct_request",error:`Direto falhou sem abrir guia: ${String(err&&err.message||err).replace(/^TypeError:\s*/,'')}`,debug:{sessionidFound:!!sessionid,steamidFound:!!steamid,source:context.source,tabDirect:tabResp}};
  }
}
async function waitForTabComplete(tabId,timeoutMs=45000){return new Promise(resolve=>{let done=false;const finish=()=>{if(done)return;done=true;try{chrome.tabs.onUpdated.removeListener(listener);}catch(_){}resolve();};const timer=setTimeout(finish,timeoutMs);function listener(id,change){if(id===tabId&&change.status==="complete"){clearTimeout(timer);finish();}}chrome.tabs.onUpdated.addListener(listener);});}
async function sendAvatarToTab(tabId,avatar,autoSubmit,mode){await executeScriptFile(tabId,"steam_avatar_content.js");return tabsSendMessage(tabId,{type:"AKAI_STEAM_AVATAR_UPLOAD",avatar,autoSubmit,uploadMode:mode});}
function isNoFileInput(result){const err=String((result&&result.error)||"").toLowerCase();return result&&!result.ok&&(result.code==="NO_FILE_INPUT"||err.includes("input[type=file]")||err.includes("não achei input"));}
async function runTabUpload(avatar,mode){const s=await getState();const avatarUrl="https://steamcommunity.com/my/edit/avatar";const active=mode==="visible_tab";const tab=await tabsCreate({url:avatarUrl,active});try{await waitForTabComplete(tab.id,45000);}catch(_){}await sleep(active?900:1800);let result;try{result=await sendAvatarToTab(tab.id,avatar,!!s.autoSubmit,mode);}catch(err){result={ok:false,mode,error:String(err.message||err),code:"TAB_SEND_FAILED"};}
if(mode==="background_tab"&&isNoFileInput(result)){const firstError=result;await tabsUpdate(tab.id,{active:true});await sleep(2200);try{result=await sendAvatarToTab(tab.id,avatar,!!s.autoSubmit,"visible_tab");}catch(err){result={ok:false,mode:"visible_tab",error:String(err.message||err),code:"TAB_SEND_FAILED"};}result={...(result||{}),fallbackFrom:"background_tab",backgroundError:firstError.error||firstError,note:(result&&result.note)||"Segundo plano falhou; abri guia visível."};}
if(mode==="background_tab"&&result&&result.ok&&s.autoSubmit&&result.clickedSubmit){setTimeout(()=>tabsRemove(tab.id).catch(()=>{}),2500);result.tabClosedAfterSuccess=true;}
return {...(result||{}),mode:result&&result.fallbackFrom?result.mode||"visible_tab":mode};}
async function runAvatar(modeOverride,source="manual"){const s=await getState();const mode=VALID_MODES.has(modeOverride)?modeOverride:s.uploadMode;await addLog({status:"running",type:"steam_avatar_upload",message:`Iniciando upload (${mode==="direct_request"?"direto sem guia":mode})`,source});const next=await getNextAvatar();let result;if(mode==="direct_request")result=await runDirectUpload(next.avatar);else result=await runTabUpload(next.avatar,mode);if(result&&result.ok)await markAvatarUsed(next.avatar.filename||next.avatar.name);await addLog({status:result&&result.ok?"done":"failed",type:"steam_avatar_upload",message:result&&result.ok?`Avatar enviado: ${next.avatar.filename}`:`Falhou: ${(result&&result.error)||"Steam recusou"}`,source,detail:result});refreshSteamLinkCacheSoon();return {ok:!!(result&&result.ok),result};}
function refreshSteamLinkCacheSoon(){[2500,7000,15000].forEach(ms=>setTimeout(()=>getSteamLinkStatus().catch(()=>{}),ms));}
async function checkRoutine(){const s=await getState();const r=s.routine||DEFAULTS.routine;if(!r.enabled)return;const now=Math.floor(Date.now()/1000);const interval=Math.max(1,Number(r.intervalMinutes||60))*60;if(r.lastRunTs&&now-r.lastRunTs<interval)return;await storageSet({routine:{...r,lastRunTs:now}});await runAvatar(s.uploadMode,"routine");}
async function openDashboard(){const tab=await tabsCreate({url:runtimeUrl("dashboard.html"),active:true});return {ok:true,tabId:tab.id};}
function setupContextMenu(){const cm=chrome.contextMenus;if(!cm)return;const ctx=(chrome.runtime.getManifest&&chrome.runtime.getManifest().manifest_version===2)?["browser_action"]:["action"];try{cm.removeAll(()=>cm.create({id:"akai-open-dashboard",title:"Abrir dashboard",contexts:ctx}));}catch(_){try{cm.create({id:"akai-open-dashboard",title:"Abrir dashboard",contexts:ctx});}catch(__){}}}
if(chrome.contextMenus&&chrome.contextMenus.onClicked){chrome.contextMenus.onClicked.addListener(info=>{if(info.menuItemId==="akai-open-dashboard")openDashboard();});}
if(chrome.commands&&chrome.commands.onCommand){chrome.commands.onCommand.addListener(command=>{if(command==="akai-run-avatar-now")runAvatar(null,"keyboard-shortcut");if(command==="akai-run-avatar-direct")runAvatar("direct_request","keyboard-shortcut-direct");});}
chrome.runtime.onInstalled.addListener(()=>{chrome.alarms.create("akai-routine",{periodInMinutes:1});chrome.alarms.create("akai-steam-link",{periodInMinutes:5});setupContextMenu();getSteamLinkStatus().catch(()=>{});tabsCreate({url:runtimeUrl("dashboard.html"),active:true}).catch(()=>{});});
chrome.runtime.onStartup.addListener(()=>{chrome.alarms.create("akai-routine",{periodInMinutes:1});chrome.alarms.create("akai-steam-link",{periodInMinutes:5});setupContextMenu();getSteamLinkStatus().catch(()=>{});});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==="akai-routine")checkRoutine().catch(err=>addLog({status:"failed",type:"routine",message:String(err.message||err)}));if(alarm.name==="akai-steam-link")getSteamLinkStatus().catch(()=>{});});
setupContextMenu();
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{(async()=>{switch(msg&&msg.type){case"AKAI_GET_STATE":sendResponse(await getState());break;case"AKAI_SET_STATE":await storageSet(msg.patch||{});sendResponse({ok:true});break;case"AKAI_GET_AVATAR_SOURCE":sendResponse(await getAvatarSource());break;case"AKAI_GET_AVATAR_PREVIEW":sendResponse(await getAvatarPreview(!!msg.forceNew));break;case"AKAI_RUN_AVATAR_NOW":sendResponse(await runAvatar(msg.mode||null,msg.source||"ui"));break;case"AKAI_STEAM_LINK_TEST":sendResponse(await getSteamLinkStatus());break;case"AKAI_GET_STEAM_LINK_CACHE":sendResponse(await getSteamLinkCache());break;case"AKAI_OPEN_DASHBOARD":sendResponse(await openDashboard());break;case"AKAI_OPEN_STEAM_AVATAR":sendResponse({ok:true,tabId:(await tabsCreate({url:"https://steamcommunity.com/my/edit/avatar",active:true})).id});break;case"AKAI_CLEAR_LOGS":await storageSet({logs:[]});sendResponse({ok:true});break;case"AKAI_FORCE_NEW_PREVIEW":await storageSet({reservedAvatarName:null});sendResponse(await getAvatarPreview(true));break;case"AKAI_BRIDGE_PING":try{sendResponse(await bridgeApi("/health"));}catch(err){sendResponse({ok:false,error:String(err.message||err)});}break;default:sendResponse({ok:false,error:"Mensagem desconhecida"});}}
)().catch(err=>sendResponse({ok:false,error:String(err.message||err)}));return true;});
