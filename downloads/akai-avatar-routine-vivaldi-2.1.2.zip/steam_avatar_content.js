(function () {
  if (window.__akaiSteamAvatarContentLoaded) return;
  window.__akaiSteamAvatarContentLoaded = true;

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function dataUrlToFile(dataUrl, filename, mime) {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([blob], filename || "avatar.png", { type: mime || blob.type || "image/png" });
  }

  function findFileInput() {
    const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
    return inputs.find(i => /image|avatar|png|jpg|jpeg|gif|webp/i.test(`${i.accept} ${i.name} ${i.id} ${i.className}`)) || inputs[0] || null;
  }

  async function waitForFileInput(timeoutMs = 22000) {
    const started = Date.now();
    let lastCount = 0;
    while (Date.now() - started < timeoutMs) {
      const input = findFileInput();
      if (input) return input;
      lastCount = document.querySelectorAll('input[type="file"]').length;
      window.scrollTo({ top: 0, behavior: "instant" });
      await sleep(500);
    }
    return null;
  }

  function textOf(el) {
    return (el.innerText || el.value || el.getAttribute("aria-label") || "").trim().toLowerCase();
  }

  function findSubmitButton() {
    const candidates = Array.from(document.querySelectorAll('button, input[type="submit"], input[type="button"], a.btn_green_white_innerfade, a, div[role="button"]'));
    const words = ["upload", "save", "salvar", "enviar", "confirm", "confirmar", "apply", "aplicar"];
    return candidates.find(el => words.some(w => textOf(el).includes(w))) || null;
  }

  function pageDebug() {
    return {
      url: location.href,
      title: document.title,
      readyState: document.readyState,
      fileInputCount: document.querySelectorAll('input[type="file"]').length,
      bodyTextSample: (document.body && document.body.innerText ? document.body.innerText.slice(0, 220) : "")
    };
  }



  function decodeHtmlEntitiesAkai(value) {
    return String(value || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&#x27;/g, "'");
  }
  function firstMatchAkai(html, patterns) {
    for (const re of patterns) {
      const m = String(html || "").match(re);
      if (m && m[1]) return decodeHtmlEntitiesAkai(m[1].trim());
    }
    return null;
  }
  function extractSessionIdAkai(html) { return firstMatchAkai(html, [/g_sessionID\s*=\s*["']([^"']+)["']/i, /name=["']sessionid["'][^>]*value=["']([^"']+)["']/i, /sessionid["']?\s*[:=]\s*["']([^"']+)["']/i]); }
  function extractSteamIdAkai(html, url = "") {
    const patterns = [/name=["']sId["'][^>]*value=["'](\d{15,20})["']/i, /g_steamID\s*=\s*["'](\d{15,20})["']/i, /["']steamid["']\s*:\s*["'](\d{15,20})["']/i, /\/profiles\/(\d{15,20})(?:\/|$)/i, /\b(7656119\d{10})\b/i];
    for (const v of [html || "", url || "", document.cookie || ""]) for (const re of patterns) { const m = String(v).match(re); if (m && m[1]) return m[1]; }
    return null;
  }
  function extractPersonaNameAkai(html) {
    const name = firstMatchAkai(html, [/<steamID><!\[CDATA\[(.*?)\]\]><\/steamID>/i, /<span[^>]+class=["'][^"']*actual_persona_name[^"']*["'][^>]*>([^<]+)<\/span>/i, /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i, /<title>(.*?)<\/title>/i]);
    return name ? name.replace(/\s*::\s*Steam Community\s*$/i, "").replace(/^Steam Community\s*::\s*/i, "").trim() : null;
  }
  function extractAvatarUrlAkai(html) { return firstMatchAkai(html, [/<avatarFull><!\[CDATA\[(.*?)\]\]><\/avatarFull>/i, /<avatarMedium><!\[CDATA\[(.*?)\]\]><\/avatarMedium>/i, /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i, /<img[^>]+src=["']([^"']+avatars[^"']+)["'][^>]*>/i]); }
  function normalizeSteamUploadResponseAkai(text) { try { return JSON.parse(text); } catch { return String(text || "").slice(0, 700); } }
  function looksLikeSteamUploadErrorAkai(text, parsed) {
    const raw = String(text || "").trim();
    if (/^#?Error_/i.test(raw) || /BadOrMissingSteamID/i.test(raw)) return true;
    if (/error/i.test(raw) && /steamid|session|avatar|upload/i.test(raw)) return true;
    if (parsed && typeof parsed === "object") {
      if (parsed.success === false || parsed.success === 0 || parsed.error || parsed.err_msg) return true;
      if (/BadOrMissingSteamID|#Error_/i.test(JSON.stringify(parsed))) return true;
    }
    return false;
  }
  async function steamContextAkai() {
    const urls = ["/my/edit/avatar", "/my?xml=1", "/my/"];
    let sessionid = extractSessionIdAkai(document.documentElement.innerHTML);
    let steamid = extractSteamIdAkai(document.documentElement.innerHTML, location.href);
    let personaName = extractPersonaNameAkai(document.documentElement.innerHTML);
    let avatarUrl = extractAvatarUrlAkai(document.documentElement.innerHTML);
    let profileUrl = location.href;
    for (const u of urls) {
      try {
        const res = await fetch(u, { credentials: "include", cache: "no-store" });
        const text = await res.text();
        sessionid = sessionid || extractSessionIdAkai(text);
        steamid = steamid || extractSteamIdAkai(text, res.url || u);
        personaName = personaName || extractPersonaNameAkai(text);
        avatarUrl = avatarUrl || extractAvatarUrlAkai(text);
        profileUrl = res.url || profileUrl;
      } catch (_) {}
    }
    return { ok: true, linked: !!(steamid || personaName || avatarUrl), personaName, avatarUrl, profileUrl, steamid, sessionid, sessionidFound: !!sessionid, canDirectAvatarUpload: !!(steamid && sessionid) };
  }
  async function directUploadAvatarAkai({ avatar, direct }) {
    if (!location.hostname.endsWith("steamcommunity.com")) return { ok: false, error: "Nenhuma guia Steam válida aberta.", code: "BAD_HOST" };
    const ctx = await steamContextAkai();
    if (!ctx.sessionid || !ctx.steamid) return { ok: false, error: "Steam aberta, mas não achei sessionid/SteamID. Confira login/Steam Guard.", code: "MISSING_CONTEXT", debug: ctx };
    const file = await dataUrlToFile(avatar.data_url, avatar.filename, avatar.mime);
    const uploadUrl = new URL((direct && direct.uploadUrl) || "/actions/FileUploader", location.origin);
    if (!uploadUrl.searchParams.has("type")) uploadUrl.searchParams.set("type", "player_avatar_image");
    if (!uploadUrl.searchParams.has("sId")) uploadUrl.searchParams.set("sId", ctx.steamid);
    if (!uploadUrl.searchParams.has("bgColor")) uploadUrl.searchParams.set("bgColor", "262627");
    const form = new FormData();
    form.append("MAX_FILE_SIZE", String(Math.max(1048576, avatar.size || file.size || 0)));
    form.append("type", "player_avatar_image");
    form.append("sId", ctx.steamid);
    form.append("sessionid", ctx.sessionid);
    form.append("doSub", "1");
    form.append("json", "1");
    form.append((direct && direct.fileField) || "avatar", file, avatar.filename || "avatar.png");
    const res = await fetch(uploadUrl.toString(), { method: "POST", body: form, credentials: "include", cache: "no-store" });
    const text = await res.text();
    const parsed = normalizeSteamUploadResponseAkai(text);
    const rejected = looksLikeSteamUploadErrorAkai(text, typeof parsed === "object" ? parsed : null);
    return { ok: res.ok && !rejected, mode: "direct_request", filename: avatar.filename, size: avatar.size, httpStatus: res.status, steamResponse: parsed, steamid: ctx.steamid, note: res.ok && !rejected ? "Avatar enviado direto pela guia Steam já aberta. Nenhuma guia nova foi aberta." : "A Steam recusou o upload direto. Nenhuma guia nova foi aberta.", debug: { source: "existing-steam-tab", sessionidFound: !!ctx.sessionid, steamidFound: !!ctx.steamid } };
  }

  async function uploadAvatar({ avatar, autoSubmit }) {
    if (!location.hostname.endsWith("steamcommunity.com")) {
      return { ok: false, error: "Esta página não é steamcommunity.com", debug: pageDebug() };
    }

    const input = await waitForFileInput();
    if (!input) {
      return {
        ok: false,
        error: "Não achei input[type=file]. A Steam pode não ter carregado a tela de avatar, estar pedindo login/Steam Guard, ou a página mudou.",
        code: "NO_FILE_INPUT",
        debug: pageDebug()
      };
    }

    const file = await dataUrlToFile(avatar.data_url, avatar.filename, avatar.mime);
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));

    await sleep(1000);

    let clicked = false;
    if (autoSubmit) {
      const btn = findSubmitButton();
      if (btn) {
        btn.click();
        clicked = true;
      }
    }

    return {
      ok: true,
      filename: avatar.filename,
      size: avatar.size,
      autoSubmit: !!autoSubmit,
      clickedSubmit: clicked,
      note: autoSubmit ? "Imagem inserida e botão tentado." : "Imagem inserida. Auto-submit desligado para revisão.",
      debug: { url: location.href, title: document.title }
    };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return;
    if (msg.type === "AKAI_STEAM_AVATAR_UPLOAD") {
      uploadAvatar(msg).then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err.message || err), code: "CONTENT_EXCEPTION", debug: pageDebug() }));
      return true;
    }
    if (msg.type === "AKAI_STEAM_GET_LINK") {
      steamContextAkai().then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err.message || err), code: "LINK_CONTEXT_EXCEPTION", debug: pageDebug() }));
      return true;
    }
    if (msg.type === "AKAI_STEAM_DIRECT_UPLOAD") {
      directUploadAvatarAkai(msg).then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err.message || err), code: "DIRECT_CONTENT_EXCEPTION", debug: pageDebug() }));
      return true;
    }
  });
})();
