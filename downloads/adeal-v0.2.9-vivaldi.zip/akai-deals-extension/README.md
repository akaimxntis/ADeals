# Akai Deals - Comparador de Preços

Extensão Manifest V3 para comparar preços de jogos e DLCs direto no popup, dashboard lateral e páginas da Steam.

## Funções incluídas

- Popup compacto com visual escuro, roxo e verde.
- Pesquisa com debounce de 450 ms.
- Placeholder animado na barra de busca, digitando e apagando exemplos de jogos.
- Resultados ordenados por menor preço.
- Melhor preço atual e menor preço histórico via IsThereAnyDeal.
- Links diretos para comprar/ver preço.
- Região e moeda visual configuráveis.
- Atalho sugerido `Alt+Shift+G`, com fallback por comando próprio. Em Vivaldi/Chrome pode precisar definir em `chrome://extensions/shortcuts`.
- Configurações salvas no `chrome.storage.local`.
- Vinculação com SteamID64 + Steam Web API Key.
- Marcação “Já tenho” via biblioteca Steam.
- Wishlist Steam por importação pública.
- Importação manual de bibliotecas GOG, Epic e outras.
- Alerta de preço por jogo.
- Notificação quando o preço fica igual ou abaixo do alvo.
- Filtro por tipo: Jogo + DLC, só jogos ou só DLCs.
- Filtro por DRM/loja: Steam Key, GOG, Epic, Ubisoft, EA, DRM-free e Keyshops.
- Página lateral estilo dashboard.
- Comparação automática em páginas de jogos da Steam.
- Instant Gaming incluída como link de busca e, opcionalmente, via API compatível.
- Textos “Clique aqui...” nas configurações, com só o “Clique aqui” sendo link para API key, SteamID64 e atalhos.

## Como instalar no Chrome/Edge/Vivaldi

1. Extraia o ZIP.
2. Abra `chrome://extensions` ou `vivaldi://extensions`.
3. Ative o **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação**.
5. Selecione a pasta `akai-deals-extension`.
6. Abra as configurações da extensão e use os botões “Clique aqui para...” para pegar as chaves.

## APIs e dados

### IsThereAnyDeal

Obrigatória para busca, preço atual, histórico e alertas.

Campo: `API Key do ITAD`.

Botão incluso: `Clique aqui para pegar API Key do ITAD`.

### Steam

Opcional, usada para:

- Marcar jogos que você já tem.
- Importar wishlist pública.
- Comparar automaticamente jogos abertos na Steam.

Campos:

- `Steam Web API Key`
- `SteamID64`

Botões inclusos:

- `Clique aqui para pegar Steam API Key`
- `Clique aqui para achar SteamID64`

A biblioteca e wishlist precisam estar públicas/acessíveis para a leitura funcionar.

### GOG/Epic manual

Cole os nomes dos jogos, um por linha. A extensão compara por nome e mostra “Já tenho” quando bater.

### Instant Gaming

Incluída de duas formas:

1. Sem API: mostra link direto para buscar na Instant Gaming.
2. Com API compatível: informe uma base como `http://127.0.0.1:5000` ou `https://instantgaming.vercel.app`.

Endpoint esperado:

```txt
GET /api/search?query=elden%20ring&latam_priority=1
```

A resposta pode ser um array direto ou `{ "results": [...] }` com campos como `title`, `price`, `url`, `currency`, `old_price`.

## Alertas

Crie alertas pelo dashboard lateral. O popup fica simples e serve só para pesquisar e abrir lojas.

A extensão verifica periodicamente usando `chrome.alarms`. Quando encontra preço menor ou igual ao alvo, dispara uma notificação do navegador.

## Dashboard lateral

O botão `▣` no popup tenta abrir o Side Panel do Chrome. Se o navegador não suportar, ele abre o dashboard em uma aba normal.

## Atalho

Abra o texto `Clique aqui para mudar o atalho da extensão` nas configurações ou vá em:

```txt
chrome://extensions/shortcuts
```

## Mudanças da v0.2.3

- Popup forçado em 420px de largura.
- Removido o modo responsivo que fazia o popup encolher demais em alguns navegadores.
- Atalho sugerido trocado para `Alt+Shift+G`. Se aparecer “Definir atalho”, configure manualmente em `chrome://extensions/shortcuts`.
- Erros de API agora tratam HTML/403 sem quebrar com `Unexpected token '<'`.
- Adicionado filtro por tipo: Jogo + DLC, só jogos e só DLCs.
- Dashboard também recebeu filtros por tipo e DRM na busca rápida.


## v0.2.4

- Popup ficou compacto em estilo lista: jogo como categoria e lojas/preços como canais.
- Removidos detalhes e criação de aviso do popup.
- Avisos de preço agora ficam só no dashboard lateral.
- Dashboard ganhou formulário próprio para criar aviso de preço.
- Região/moeda agora podem ser detectadas automaticamente pelo navegador.
- Links da Steam recebem `cc=<região>` para abrir com preço regional quando possível.


## v0.2.5

- Cards do popup refeitos de verdade em modo compacto.
- Visual tipo Discord: título do jogo como categoria e lojas/preços como linhas.
- Popup não mostra criação de aviso nem detalhes grandes.
- Instant Gaming sem API agora entra como linha dentro do jogo principal, não como card separado.
- Resultados exatos agora priorizam o jogo principal e reduzem extras da GOG, goodies, HQs, artbooks e histórias bônus.
- Filtro padrão mudou para **Só jogos**; DLCs continuam disponíveis no filtro.
- Lojas duplicadas são agrupadas, mantendo o menor preço por loja.


## v0.2.6

- Lista do popup mostra mais jogos por busca.
- Adicionado sorting por Popularidade, Relevância, Menor preço, Mais lojas e A-Z.
- Busca do ITAD puxa mais candidatos e mais lojas por jogo.
- Redução de extras/barulhos como artbook, HQ, wallpapers, bônus e goodies.

## v0.2.9

- Deixei o comparador automático em páginas da Steam bem mais compacto.
- Removi o botão de criar alerta do mini-popup da loja. Alertas continuam no dashboard/barra lateral.
- O mini-popup agora mostra o jogo em uma linha e as lojas/preços em lista simples.
- Agrupa lojas duplicadas e mantém o menor preço por loja.
- Mantém link direto para a melhor oferta e aplica região no link da Steam quando possível.
