const DEFAULT_SETTINGS = {
  itadApiKey: "",
  country: "BR",
  currency: "BRL",
  autoDetectRegion: true,
  resultsLimit: 12,
  drmFilter: "all",
  typeFilter: "game",
  sortMode: "popular",
  steamApiKey: "",
  steamId64: "",
  instantGamingEnabled: true,
  instantGamingApiBase: "",
  instantGamingLatamPriority: true,
  compareOnSteam: true,
  notificationsEnabled: true,
  ownedCache: null,
  ownedCacheUpdatedAt: 0,
  wishlistCache: null,
  wishlistCacheUpdatedAt: 0,
  manualLibrary: { gog: [], epic: [], other: [] },
  priceAlerts: [],
  notificationLinks: {}
};

chrome.runtime.onInstalled.addListener(async (details) => {
  const existing = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  const missing = Object.fromEntries(
    Object.entries(DEFAULT_SETTINGS).filter(([key]) => existing[key] === undefined)
  );
  if (Object.keys(missing).length) await chrome.storage.local.set(missing);
  if (details?.reason === "update") {
    const updatePatch = { typeFilter: "game" };
    const savedLimit = Number(existing.resultsLimit || 0);
    if (!Number.isFinite(savedLimit) || savedLimit < 12) updatePatch.resultsLimit = 12;
    if (!existing.sortMode) updatePatch.sortMode = "popular";
    await chrome.storage.local.set(updatePatch);
  }

  chrome.alarms.create("akai-deals-price-alerts", { periodInMinutes: 30 });

  if (chrome.sidePanel?.setPanelBehavior) {
    try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }); } catch {}
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "akai-deals-price-alerts") checkPriceAlerts(false);
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "open-akai-deals") {
    await openAkaiPopup();
  }

  if (command === "open-akai-dashboard") {
    await openAkaiDashboard();
  }
});

async function openAkaiPopup() {
  try {
    if (chrome.action?.openPopup) {
      await chrome.action.openPopup();
      return;
    }
  } catch (error) {
    console.warn("Não foi possível abrir o popup direto; abrindo em aba.", error);
  }
  chrome.tabs.create({ url: chrome.runtime.getURL("popup/popup.html") });
}

async function openAkaiDashboard() {
  const url = chrome.runtime.getURL("dashboard/dashboard.html");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (chrome.sidePanel?.open && tab?.id) {
      await chrome.sidePanel.open({ tabId: tab.id });
      return;
    }
  } catch (error) {
    console.warn("Não foi possível abrir side panel; abrindo dashboard em aba.", error);
  }
  chrome.tabs.create({ url });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === "compareTitle") {
        const settings = await getSettings();
        if (!settings.compareOnSteam) return sendResponse({ ok: true, disabled: true });
        const results = await searchDeals(message.title, { limit: 4, typeFilter: message.typeFilter || "game", includeFallback: true });
        return sendResponse({ ok: true, results });
      }

      if (message?.type === "searchDeals") {
        const results = await searchDeals(message.query, message.options || {});
        return sendResponse({ ok: true, results });
      }

      if (message?.type === "createAlert") {
        const alert = await createPriceAlert(message.alert || {});
        return sendResponse({ ok: true, alert });
      }

      if (message?.type === "checkAlertsNow") {
        const updated = await checkPriceAlerts(true);
        return sendResponse({ ok: true, updated });
      }

      if (message?.type === "openOptions") {
        chrome.runtime.openOptionsPage();
        return sendResponse({ ok: true });
      }

      return sendResponse({ ok: false, error: "Mensagem desconhecida." });
    } catch (error) {
      console.error(error);
      return sendResponse({ ok: false, error: error.message || "Erro interno." });
    }
  })();
  return true;
});

chrome.notifications.onClicked.addListener(async (notificationId) => {
  const { notificationLinks = {} } = await chrome.storage.local.get({ notificationLinks: {} });
  const url = notificationLinks[notificationId];
  if (url) chrome.tabs.create({ url });
});

async function getSettings() {
  const settings = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
  if (settings.autoDetectRegion !== false) {
    const detected = detectUserRegion();
    settings.country = detected.country;
    settings.currency = detected.currency;
    settings.detectedRegion = true;
  }
  return settings;
}

function detectUserRegion() {
  const language = chrome.i18n?.getUILanguage?.() || globalThis.navigator?.language || "pt-BR";
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
  const countryFromLang = (String(language).match(/[-_]([A-Z]{2})$/i)?.[1] || "").toUpperCase();
  const timeZoneCountry = detectCountryByTimezone(timeZone);
  const country = countryFromLang || timeZoneCountry || "BR";
  return { country, currency: currencyForCountry(country) };
}

function detectCountryByTimezone(timeZone) {
  const tz = String(timeZone).toLowerCase();
  if (tz.includes("sao_paulo") || tz.includes("brasil")) return "BR";
  if (tz.includes("buenos_aires")) return "AR";
  if (tz.includes("santiago")) return "CL";
  if (tz.includes("mexico")) return "MX";
  if (tz.includes("lisbon") || tz.includes("azores") || tz.includes("madeira")) return "PT";
  if (tz.includes("london")) return "GB";
  if (tz.includes("tokyo")) return "JP";
  return "";
}

function currencyForCountry(country) {
  return ({
    BR: "BRL", US: "USD", AR: "ARS", CL: "CLP", MX: "MXN", PT: "EUR",
    GB: "GBP", JP: "JPY", CA: "CAD", AU: "AUD", DE: "EUR", FR: "EUR",
    ES: "EUR", IT: "EUR", NL: "EUR"
  })[country] || "USD";
}

async function createPriceAlert(input) {
  const settings = await getSettings();
  const title = String(input.title || "").trim();
  const target = Number(input.target);
  if (!title || !Number.isFinite(target) || target <= 0) throw new Error("Preencha jogo e preço alvo." );

  const alert = {
    id: crypto.randomUUID(),
    title,
    target,
    currency: input.currency || settings.currency || "BRL",
    drmFilter: input.drmFilter || settings.drmFilter || "all",
    typeFilter: input.typeFilter || settings.typeFilter || "all",
    enabled: true,
    createdAt: Date.now(),
    lastPrice: input.currentPrice ?? null,
    lastShop: input.currentShop || "",
    lastUrl: input.url || "",
    lastCheckedAt: 0,
    lastNotifiedAt: 0
  };

  const priceAlerts = Array.isArray(settings.priceAlerts) ? settings.priceAlerts : [];
  await chrome.storage.local.set({ priceAlerts: [alert, ...priceAlerts] });
  return alert;
}

async function checkPriceAlerts(manual = false) {
  const settings = await getSettings();
  if (!settings.itadApiKey) return [];

  const alerts = Array.isArray(settings.priceAlerts) ? settings.priceAlerts : [];
  const nextAlerts = [];
  const updated = [];

  for (const alert of alerts) {
    if (!alert.enabled) {
      nextAlerts.push(alert);
      continue;
    }

    try {
      const results = await searchDeals(alert.title, { limit: 3, drmFilter: alert.drmFilter, typeFilter: alert.typeFilter, includeFallback: false });
      const best = results.find((item) => item.current && Number.isFinite(priceValue(item.current)));
      const now = Date.now();
      const next = {
        ...alert,
        lastCheckedAt: now,
        lastPrice: best?.current?.price?.amount ?? alert.lastPrice ?? null,
        lastShop: best?.current?.shop?.name || alert.lastShop || "",
        lastUrl: best?.buyUrl || alert.lastUrl || ""
      };

      if (best?.current && Number(best.current.price.amount) <= Number(alert.target)) {
        const cooldownMs = manual ? 0 : 6 * 60 * 60 * 1000;
        if (!alert.lastNotifiedAt || now - alert.lastNotifiedAt > cooldownMs) {
          await notifyPriceHit(next, best);
          next.lastNotifiedAt = now;
        }
      }

      nextAlerts.push(next);
      updated.push(next);
    } catch (error) {
      console.warn("Falha ao verificar alerta", alert.title, error);
      nextAlerts.push({ ...alert, lastCheckedAt: Date.now(), lastError: error.message || "Erro" });
    }
  }

  await chrome.storage.local.set({ priceAlerts: nextAlerts });
  return updated;
}

async function notifyPriceHit(alert, best) {
  const settings = await getSettings();
  if (!settings.notificationsEnabled) return;

  const notificationId = `akai-deals-${alert.id}-${Date.now()}`;
  const price = formatMoney(best.current.price);
  const target = formatMoney({ amount: alert.target, currency: alert.currency || best.current.price.currency || "BRL" });

  chrome.notifications.create(notificationId, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: `Preço alvo batido: ${alert.title}`,
    message: `${price} em ${best.current.shop?.name || "loja"}. Alvo: ${target}. Clique para abrir.`
  });

  const { notificationLinks = {} } = await chrome.storage.local.get({ notificationLinks: {} });
  notificationLinks[notificationId] = best.buyUrl || best.itadUrl;
  await chrome.storage.local.set({ notificationLinks });
}

async function searchDeals(query, options = {}) {
  const settings = await getSettings();
  const limit = clamp(Number(options.limit || settings.resultsLimit || 12), 1, 40);
  const drmFilter = options.drmFilter || settings.drmFilter || "all";
  const typeFilter = options.typeFilter || settings.typeFilter || "all";
  const sortMode = options.sortMode || settings.sortMode || "popular";

  if (!query || String(query).trim().length < 2) return [];

  const [itadResults, instantResults] = await Promise.all([
    settings.itadApiKey ? searchItad(String(query).trim(), settings, limit, drmFilter, typeFilter) : Promise.resolve([]),
    searchInstantGaming(String(query).trim(), settings, Boolean(options.includeFallback), typeFilter).catch(() => [])
  ]);

  const merged = mergeResults(itadResults, instantResults, String(query).trim(), settings)
    .map((item) => regionalizeResult(item, settings))
    .filter((item) => matchesTypeFilter(item, typeFilter))
    .filter((item) => !isNoisyExtra(item, typeFilter))
    .map((item) => ({
      ...item,
      typeFilter,
      deals: dedupeDealsByShop(item.deals || []),
      owned: isOwnedByTitle(item.title, settings),
      ownedSources: getOwnedSources(item.title, settings),
      wishlisted: isWishlistedByTitle(item.title, settings),
      relevance: rankGameForQuery(item, String(query).trim()),
      popularity: estimatePopularity(item, String(query).trim())
    }));

  return sortResults(merged, sortMode)
    .slice(0, limit);
}

async function searchItad(query, settings, limit, drmFilter, typeFilter = "all") {
  const variants = buildQueryVariants(query);
  const wanted = normalizeTitle(query);
  const wantedStrict = normalizeTitleForExact(query);
  const candidates = [];
  const seenIds = new Set();
  const targetCount = clamp(Math.max(limit * 5, 45), 20, 80);

  for (const variant of variants) {
    const results = await searchItadVariant(variant, settings, targetCount).catch((error) => {
      if (/403|API Key|Limite da API|Erro \d+ na API/i.test(error?.message || "")) throw error;
      console.warn("Falha ao buscar variante ITAD", variant, error);
      return [];
    });

    for (const game of results) {
      if (!game?.id || seenIds.has(game.id)) continue;
      seenIds.add(game.id);
      candidates.push({ ...game, matchedVariant: variant });
    }
  }

  if (!candidates.length) return [];

  candidates.sort((a, b) => {
    const aExact = normalizeTitleForExact(a.title) === wantedStrict ? 1 : 0;
    const bExact = normalizeTitleForExact(b.title) === wantedStrict ? 1 : 0;
    return bExact - aExact || rankCandidateTitle(b.title, wanted) - rankCandidateTitle(a.title, wanted);
  });

  const ids = candidates.slice(0, targetCount).map((game) => game.id).filter(Boolean);
  const overviewUrl = new URL("https://api.isthereanydeal.com/games/overview/v2");
  overviewUrl.searchParams.set("key", settings.itadApiKey);
  overviewUrl.searchParams.set("country", settings.country || "BR");
  overviewUrl.searchParams.set("vouchers", "true");

  const overview = await fetchJson(overviewUrl.toString(), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(ids)
  });

  const overviewMap = new Map((overview?.prices || []).map((item) => [item.id, item]));

  const pricesUrl = new URL("https://api.isthereanydeal.com/games/prices/v3");
  pricesUrl.searchParams.set("key", settings.itadApiKey);
  pricesUrl.searchParams.set("country", settings.country || "BR");
  pricesUrl.searchParams.set("vouchers", "true");
  pricesUrl.searchParams.set("capacity", "25");

  const priceDetails = await fetchJson(pricesUrl.toString(), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(ids)
  });

  const dealsMap = new Map((Array.isArray(priceDetails) ? priceDetails : []).map((item) => [item.id, item.deals || []]));

  return candidates.map((game) => {
    const ov = overviewMap.get(game.id) || {};
    const allDeals = (dealsMap.get(game.id) || []).map(normalizeDeal).filter(Boolean);
    const deals = filterDealsByDRM(allDeals, drmFilter);
    const currentFromOverview = normalizeDeal(ov.current);
    const current = filterDealsByDRM([currentFromOverview].filter(Boolean), drmFilter)[0] || deals[0] || null;
    const lowest = normalizeDeal(ov.lowest, true) || null;

    return {
      source: "ITAD",
      id: game.id,
      title: game.title,
      type: normalizeGameType(game.type, game.title),
      image: getGameImage(game),
      current,
      lowest,
      deals,
      drmFilter,
      matchedVariant: game.matchedVariant,
      itadUrl: ov.urls?.game || `https://isthereanydeal.com/search/?q=${encodeURIComponent(game.title)}`,
      buyUrl: current?.url || ov.urls?.game || `https://isthereanydeal.com/search/?q=${encodeURIComponent(game.title)}`
    };
  });
}

async function searchItadVariant(query, settings, resultCount) {
  const items = [];

  const searchUrl = new URL("https://api.isthereanydeal.com/games/search/v1");
  searchUrl.searchParams.set("key", settings.itadApiKey);
  searchUrl.searchParams.set("title", query);
  searchUrl.searchParams.set("results", String(resultCount));

  const searchResults = await fetchJson(searchUrl.toString());
  if (Array.isArray(searchResults)) items.push(...searchResults);

  const lookupUrl = new URL("https://api.isthereanydeal.com/games/lookup/v1");
  lookupUrl.searchParams.set("key", settings.itadApiKey);
  lookupUrl.searchParams.set("title", query);

  const lookup = await fetchJson(lookupUrl.toString()).catch(() => null);
  if (Array.isArray(lookup)) items.push(...lookup);
  else if (lookup?.id) items.unshift(lookup);

  return items;
}

function buildQueryVariants(query) {
  const original = String(query || "").trim();
  const normalized = normalizeTitleForExact(original);
  const noSubtitle = original.replace(/\s*[:–—-]\s*.+$/, "").trim();
  const noPunctuation = original.replace(/[:–—]/g, " ").replace(/\s+/g, " ").trim();
  const compact = noPunctuation.replace(/\b(the|game of the year|goty|complete|edition|deluxe|ultimate|definitive|enhanced)\b/gi, " ").replace(/\s+/g, " ").trim();
  const aliases = [];

  if (/\bwitcher\s*(3|iii)\b/i.test(original) || normalized.includes("witcher 3") || normalized.includes("witcher iii")) {
    aliases.push("The Witcher 3: Wild Hunt", "The Witcher 3 Wild Hunt", "The Witcher 3", "Witcher 3", "The Witcher III: Wild Hunt");
  }
  if (/\bcyberpunk\s*2077\b/i.test(original)) aliases.push("Cyberpunk 2077");
  if (/\bgrand\s+theft\s+auto\b/i.test(original) || /\bgta\b/i.test(original)) aliases.push("Grand Theft Auto", "GTA", "Grand Theft Auto V", "Grand Theft Auto IV");
  if (/\bred\s+dead\s+redemption\s*2\b/i.test(original) || /\brdr\s*2\b/i.test(original)) aliases.push("Red Dead Redemption 2", "Red Dead Redemption II");
  if (/\bbaldur'?s\s+gate\s*3\b/i.test(original)) aliases.push("Baldur's Gate 3", "Baldurs Gate 3");

  return uniqueStrings([original, noPunctuation, noSubtitle, compact, ...aliases])
    .filter((item) => item.length >= 2)
    .slice(0, 7);
}

function uniqueStrings(items) {
  const seen = new Set();
  const out = [];
  for (const item of items) {
    const value = String(item || "").trim().replace(/\s+/g, " ");
    const key = value.toLowerCase();
    if (!value || seen.has(key)) continue;
    seen.add(key);
    out.push(value);
  }
  return out;
}

function rankCandidateTitle(title, normalizedQuery) {
  const t = normalizeTitle(title);
  const q = normalizedQuery;
  if (!t || !q) return 0;
  let score = rankGameForQuery({ title }, q);
  if (isNoisyExtra({ title, type: normalizeGameType("", title) }, "game")) score -= 120;
  if (t.includes("redkit") || t.includes("editor") || t.includes("tool")) score -= 100;
  return score;
}

function normalizeTitleForExact(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/&/g, " and ")
    .replace(/\biii\b/g, "3")
    .replace(/\bii\b/g, "2")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

async function searchInstantGaming(query, settings, includeFallback = true, typeFilter = "all") {
  if (!settings.instantGamingEnabled) return [];

  const apiBase = (settings.instantGamingApiBase || "").trim().replace(/\/$/, "");
  if (!apiBase) return includeFallback ? [instantGamingFallback(query, typeFilter)] : [];

  const url = new URL(`${apiBase}/api/search`);
  url.searchParams.set("query", query);
  url.searchParams.set("latam_priority", settings.instantGamingLatamPriority ? "1" : "0");
  url.searchParams.set("max_details", "5");

  const data = await fetchJson(url.toString());
  const items = Array.isArray(data) ? data : data.results || data.items || [];
  if (!Array.isArray(items) || items.length === 0) return includeFallback ? [instantGamingFallback(query, typeFilter)] : [];

  return items.slice(0, 5).map((item) => {
    const title = item.title || item.name || item.game || query;
    const price = parsePrice(item.price || item.current_price || item.latam_price || item.amount);
    const regular = parsePrice(item.regular || item.old_price || item.original_price);
    const url = item.url || item.link || `https://www.instant-gaming.com/en/search/?query=${encodeURIComponent(query)}`;
    const currency = item.currency || inferCurrency(item.price) || settings.currency || "BRL";
    const deal = price ? {
      shop: { name: "Instant Gaming" },
      price: { amount: price, currency },
      regular: regular ? { amount: regular, currency } : null,
      cut: regular && price ? Math.max(0, Math.round((1 - price / regular) * 100)) : null,
      url,
      drm: ["Steam Key", "Keyshop"]
    } : null;

    return {
      source: "Instant Gaming",
      id: `ig-${normalizeTitle(title)}`,
      title,
      type: normalizeGameType(item.type || item.kind || "game", title),
      current: deal,
      lowest: null,
      deals: deal ? [deal] : [],
      itadUrl: `https://www.instant-gaming.com/en/search/?query=${encodeURIComponent(query)}`,
      buyUrl: url,
      hasInstantGaming: true,
      instantFallback: false
    };
  });
}

function instantGamingFallback(query, typeFilter = "all") {
  const url = `https://www.instant-gaming.com/en/search/?query=${encodeURIComponent(query)}`;
  return {
    source: "Instant Gaming",
    id: `ig-search-${normalizeTitle(query)}`,
    title: `Buscar “${query}” na Instant Gaming`,
    type: typeFilter === "dlc" ? "search_dlc" : "search",
    current: null,
    lowest: null,
    deals: [],
    itadUrl: url,
    buyUrl: url,
    hasInstantGaming: true,
    instantFallback: true
  };
}

function mergeResults(itadResults, instantResults, query) {
  const all = [...itadResults];
  for (const ig of instantResults || []) {
    if (ig.instantFallback && all.length) {
      const target = findBestGameForQuery(all, query) || all[0];
      target.deals = [...(target.deals || []), {
        shop: { name: "Instant Gaming" },
        price: null,
        regular: null,
        cut: null,
        url: ig.buyUrl || ig.itadUrl,
        drm: ["Steam Key", "Keyshop"]
      }];
      target.hasInstantGaming = true;
      continue;
    }

    const match = all.find((game) => similarity(normalizeTitle(game.title), normalizeTitle(ig.title)) > 0.88);
    if (match && ig.current) {
      match.deals = [...(match.deals || []), normalizeDeal(ig.current)].filter(Boolean).sort((a, b) => priceValue(a) - priceValue(b));
      if (priceValue(ig.current) < priceValue(match.current)) {
        match.current = normalizeDeal(ig.current);
        match.buyUrl = ig.buyUrl;
      }
      match.hasInstantGaming = true;
    } else {
      all.push(ig);
    }
  }
  return all;
}

function findBestGameForQuery(items, query) {
  return [...items].sort((a, b) => rankGameForQuery(b, query) - rankGameForQuery(a, query))[0] || null;
}

function sortResults(items, mode = "popular") {
  const list = [...(items || [])];
  if (mode === "price") return list.sort((a, b) => priceValue(a.current) - priceValue(b.current) || b.relevance - a.relevance);
  if (mode === "name") return list.sort((a, b) => String(a.title || "").localeCompare(String(b.title || ""), "pt-BR"));
  if (mode === "stores") return list.sort((a, b) => (b.deals?.length || 0) - (a.deals?.length || 0) || b.relevance - a.relevance);
  if (mode === "relevance") return list.sort((a, b) => b.relevance - a.relevance || b.popularity - a.popularity || priceValue(a.current) - priceValue(b.current));
  return list.sort((a, b) => b.popularity - a.popularity || b.relevance - a.relevance || priceValue(a.current) - priceValue(b.current));
}

function estimatePopularity(item, query) {
  const deals = dedupeDealsByShop(item?.deals || []);
  const shops = deals.map((deal) => String(deal?.shop?.name || "").toLowerCase());
  const majorStores = ["steam", "gog", "epic", "nuuvem", "fanatical", "green man", "humble", "gamesplanet", "gamersgate", "indiegala", "gamebillet", "microsoft", "ubisoft", "ea"];
  let score = 0;
  score += Math.min(70, deals.length * 6);
  score += majorStores.filter((name) => shops.some((shop) => shop.includes(name))).length * 5;
  score += Math.round(rankGameForQuery(item, query) * 0.55);
  if (item?.current && Number.isFinite(priceValue(item.current))) score += 10;
  if (item?.hasInstantGaming) score += 2;
  const type = normalizeGameType(item?.type, item?.title);
  if (type === "game") score += 12;
  if (type === "dlc") score -= 8;
  if (type === "package") score -= 10;
  if (type === "extra") score -= 80;
  if (isNoisyExtra(item, "game")) score -= 60;
  return score;
}

function regionalizeResult(item, settings) {
  const country = settings.country || "BR";
  const current = item.current ? { ...item.current, url: addRegionToUrl(item.current.url, country) } : item.current;
  const lowest = item.lowest ? { ...item.lowest, url: addRegionToUrl(item.lowest.url, country) } : item.lowest;
  const deals = (item.deals || []).map((deal) => ({ ...deal, url: addRegionToUrl(deal.url, country) }));
  return {
    ...item,
    current,
    lowest,
    deals,
    buyUrl: addRegionToUrl(item.buyUrl, country),
    itadUrl: addRegionToUrl(item.itadUrl, country)
  };
}

function addRegionToUrl(url, country) {
  if (!url || !country) return url;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host.includes("steampowered.com")) parsed.searchParams.set("cc", country);
    if (host.includes("isthereanydeal.com")) parsed.searchParams.set("country", country);
    return parsed.toString();
  } catch {
    return url;
  }
}

async function fetchJson(url, init = {}) {
  const response = await fetch(url, init);
  const text = await response.text();

  if (!response.ok) {
    if (response.status === 403) throw new Error("Erro 403 na API. Confira se a API Key está correta/ativa.");
    if (response.status === 429) throw new Error("Limite da API atingido.");
    throw new Error(`Erro ${response.status} na API.`);
  }

  try {
    return text ? JSON.parse(text) : null;
  } catch {
    if (/^\s*</.test(text)) throw new Error("A API devolveu HTML em vez de JSON. Confira a URL/API Key ou privacidade do perfil.");
    throw new Error("Resposta inválida da API: não é JSON.");
  }
}

function normalizeDeal(deal, historical = false) {
  if (!deal) return null;
  return {
    shop: deal.shop || { name: deal.shopName || "Loja" },
    price: deal.price || null,
    regular: deal.regular || null,
    cut: deal.cut ?? null,
    url: deal.url || null,
    drm: deal.drm || deal.drmProtection || deal.platforms || deal.launchers || [],
    historical
  };
}

function filterDealsByDRM(deals, filter) {
  if (!filter || filter === "all") return deals;
  return deals.filter((deal) => matchesDRM(deal, filter));
}

function matchesDRM(deal, filter) {
  const hay = [
    deal?.shop?.name,
    deal?.url,
    ...(Array.isArray(deal?.drm) ? deal.drm : [deal?.drm])
  ].filter(Boolean).join(" ").toLowerCase();

  const rules = {
    steam: ["steam"],
    gog: ["gog", "drm-free", "drm free"],
    epic: ["epic"],
    ubisoft: ["ubisoft", "uplay", "ubisoft connect"],
    ea: ["ea app", "origin", "electronic arts"],
    drmfree: ["drm-free", "drm free", "gog"],
    keyshop: ["key", "instant gaming", "keyshop"]
  };
  return (rules[filter] || []).some((term) => hay.includes(term));
}

function normalizeGameType(type, title = "") {
  const raw = String(type || "").toLowerCase();
  const name = String(title || "").toLowerCase();
  if (isNoisyTitle(name)) return "extra";
  if (/\b(redkit|sdk|toolkit|tool kit|editor|modding tool|development kit|benchmark|demo|trial|beta|test server|public test|server)\b/i.test(name)) return "extra";
  if (raw.includes("dlc") || raw.includes("downloadable") || /\b(dlc|season pass|expansion|add-on|add on|chapter|episode|story pack|character pack|map pack)\b/i.test(name)) return "dlc";
  if (raw.includes("pack") || raw.includes("bundle") || /\b(bundle|collection|trilogy|anthology|pack)\b/i.test(name)) return "package";
  if (raw.includes("game") || !raw) return "game";
  if (raw.includes("search")) return raw;
  return raw;
}

function matchesTypeFilter(item, filter) {
  if (!filter || filter === "all") return true;
  if (item?.instantFallback) return true;
  const type = normalizeGameType(item?.type, item?.title);
  if (filter === "dlc") return type === "dlc";
  if (filter === "game") {
    return type === "game"
      || (type === "package" && isAcceptableGamePackage(item?.title))
      || (!type && !/\b(dlc|season pass|expansion|add-on|add on)\b/i.test(item?.title || ""));
  }
  return true;
}


function getGameImage(game) {
  const assets = game?.assets || game?.image || game?.images || {};
  if (typeof assets === "string") return assets;
  return assets.boxart || assets.banner145 || assets.banner300 || assets.cover || assets.logo || assets.icon || game?.cover || "";
}

function dedupeDealsByShop(deals) {
  const best = new Map();
  for (const deal of deals || []) {
    if (!deal) continue;
    const key = String(deal.shop?.name || "Loja").toLowerCase().replace(/[^a-z0-9]+/g, "");
    const current = best.get(key);
    if (!current || priceValue(deal) < priceValue(current)) best.set(key, deal);
  }
  return [...best.values()].sort((a, b) => priceValue(a) - priceValue(b));
}

function rankGameForQuery(item, query) {
  const q = normalizeTitle(query);
  const t = normalizeTitle(item?.title);
  if (!q || !t) return 0;
  if (t === q) return 120;
  if (t.startsWith(q)) return 95 - Math.min(25, t.length - q.length);
  if (q.startsWith(t)) return 90 - Math.min(20, q.length - t.length);
  const sim = similarity(t, q);
  return Math.round(sim * 80);
}

function isNoisyExtra(item, typeFilter) {
  const title = String(item?.title || "").toLowerCase();
  const type = normalizeGameType(item?.type, item?.title);
  if (typeFilter === "dlc") return false;
  const noisyTitle = isNoisyTitle(title);
  if (typeFilter === "all") return type === "extra" || noisyTitle;
  return type === "extra" || noisyTitle || (type === "package" && !isAcceptableGamePackage(title));
}

function isAcceptableGamePackage(title) {
  const name = String(title || "").toLowerCase();
  return /\b(complete|definitive|deluxe|ultimate|goty|game of the year|enhanced|anniversary|director'?s cut|special edition)\b/i.test(name)
    && !/\b(bundle|pack|collection|trilogy|anthology|soundtrack|artbook|goodies|bonus)\b/i.test(name);
}

function isNoisyTitle(title) {
  const name = String(title || "").toLowerCase();
  return /\b(soundtrack|original soundtrack|ost|music pack|artbook|art book|digital art|comic|comics|digital comic|goodies|digital goodies|bonus content|bonus material|bonus pack|wallpaper|wallpapers|avatar|avatars|profile pack|manual|lore book|sourcebook|short story|short stories|stories collection|concept art|poster|posters|sound selection|making of|behind the scenes|press kit|redkit|modding tool|toolkit|tool kit|editor|sdk|starter pack|supporter pack|vr mod|hd texture pack|language pack|ringtones)\b/i.test(name);
}

function getOwnedSources(title, settings) {
  const n = normalizeTitle(title);
  const sources = [];
  const steamGames = settings.ownedCache?.games || [];
  if (steamGames.some((name) => titleMatches(n, normalizeTitle(name)))) sources.push("Steam");
  const manual = settings.manualLibrary || {};
  if ((manual.gog || []).some((name) => titleMatches(n, normalizeTitle(name)))) sources.push("GOG");
  if ((manual.epic || []).some((name) => titleMatches(n, normalizeTitle(name)))) sources.push("Epic");
  if ((manual.other || []).some((name) => titleMatches(n, normalizeTitle(name)))) sources.push("Manual");
  return sources;
}

function isOwnedByTitle(title, settings) {
  return getOwnedSources(title, settings).length > 0;
}

function isWishlistedByTitle(title, settings) {
  const n = normalizeTitle(title);
  return (settings.wishlistCache?.games || []).some((game) => titleMatches(n, normalizeTitle(game.name || game.title || game)));
}

function titleMatches(a, b) {
  if (!a || !b) return false;
  return a === b || a.includes(b) || b.includes(a) || similarity(a, b) > 0.92;
}

function formatMoney(price) {
  if (!price || price.amount === undefined || price.amount === null) return "—";
  const currency = price.currency || "BRL";
  try { return new Intl.NumberFormat("pt-BR", { style: "currency", currency }).format(Number(price.amount)); }
  catch { return `${currency} ${Number(price.amount).toFixed(2)}`; }
}

function priceValue(deal) {
  const amount = deal?.price?.amount;
  return amount === undefined || amount === null ? Number.POSITIVE_INFINITY : Number(amount);
}

function parsePrice(value) {
  if (typeof value === "number") return value;
  if (!value || typeof value !== "string") return null;
  const cleaned = value.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".");
  const n = Number.parseFloat(cleaned);
  return Number.isFinite(n) ? n : null;
}

function inferCurrency(value) {
  if (typeof value !== "string") return null;
  if (value.includes("R$")) return "BRL";
  if (value.includes("€")) return "EUR";
  if (value.includes("£")) return "GBP";
  if (value.includes("$")) return "USD";
  return null;
}

function normalizeTitle(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\b(complete|edition|deluxe|ultimate|goty|game of the year|remaster|remastered|definitive|enhanced|director s cut|anniversary)\b/g, "")
    .trim();
}

function similarity(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const longer = a.length > b.length ? a : b;
  const shorter = a.length > b.length ? b : a;
  if (!longer.length) return 1;
  return (longer.length - levenshtein(longer, shorter)) / longer.length;
}

function levenshtein(a, b) {
  const matrix = Array.from({ length: b.length + 1 }, (_, i) => [i]);
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      matrix[i][j] = b.charAt(i - 1) === a.charAt(j - 1)
        ? matrix[i - 1][j - 1]
        : Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
    }
  }
  return matrix[b.length][a.length];
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
