const DEFAULT_SETTINGS = {
  country: "BR",
  currency: "BRL",
  autoDetectRegion: true,
  resultsLimit: 12,
  drmFilter: "all",
  typeFilter: "game",
  sortMode: "popular",
  itadApiKey: "",
  ownedCache: null,
  wishlistCache: null,
  manualLibrary: { gog: [], epic: [], other: [] }
};

const els = {
  input: document.querySelector("#searchInput"),
  clear: document.querySelector("#clearBtn"),
  status: document.querySelector("#status"),
  results: document.querySelector("#results"),
  options: document.querySelector("#openOptions"),
  dashboard: document.querySelector("#openDashboard"),
  region: document.querySelector("#regionBadge"),
  wishlistCount: document.querySelector("#wishlistCount"),
  libraryCount: document.querySelector("#libraryCount"),
  drmFilter: document.querySelector("#drmFilter"),
  typeFilter: document.querySelector("#typeFilter"),
  sortMode: document.querySelector("#sortMode"),
  resultTpl: document.querySelector("#resultTemplate"),
  dealTpl: document.querySelector("#dealTemplate")
};

let settings = { ...DEFAULT_SETTINGS };
let debounceId = null;
let requestSeq = 0;
let placeholderTimer = null;

const PLACEHOLDER_GAMES = [
  "Cyberpunk 2077",
  "Grand Theft Auto V",
  "Red Dead Redemption 2",
  "Elden Ring",
  "Forza Horizon 5",
  "Resident Evil 4",
  "Baldur's Gate 3",
  "The Witcher 3",
  "Hades",
  "Stardew Valley"
];

init();

async function init() {
  settings = await loadEffectiveSettings();
  els.region.textContent = `${settings.country || "BR"} / ${settings.currency || "BRL"}${settings.autoDetectRegion !== false ? " auto" : ""}`;
  els.drmFilter.value = settings.drmFilter || "all";
  els.typeFilter.value = settings.typeFilter || "game";
  els.sortMode.value = settings.sortMode || "popular";
  updateCounters();
  updateShortcutBadge();
  document.querySelector("#shortcutBadge")?.addEventListener("click", () => chrome.tabs.create({ url: "chrome://extensions/shortcuts" }));
  startAnimatedPlaceholder();

  els.options.addEventListener("click", () => chrome.runtime.openOptionsPage());
  els.dashboard.addEventListener("click", () => openDashboard());
  els.clear.addEventListener("click", () => {
    els.input.value = "";
    els.results.innerHTML = "";
    setStatus("Digite o nome de um jogo para comparar preços.");
    startAnimatedPlaceholder(true);
    els.input.focus();
  });

  els.drmFilter.addEventListener("change", async () => {
    settings.drmFilter = els.drmFilter.value;
    await chrome.storage.local.set({ drmFilter: settings.drmFilter });
    if (els.input.value.trim().length >= 2) search(els.input.value.trim());
  });

  els.typeFilter.addEventListener("change", async () => {
    settings.typeFilter = els.typeFilter.value;
    await chrome.storage.local.set({ typeFilter: settings.typeFilter });
    if (els.input.value.trim().length >= 2) search(els.input.value.trim());
  });

  els.sortMode.addEventListener("change", async () => {
    settings.sortMode = els.sortMode.value;
    await chrome.storage.local.set({ sortMode: settings.sortMode });
    if (els.input.value.trim().length >= 2) search(els.input.value.trim());
  });

  els.input.addEventListener("input", () => {
    clearTimeout(debounceId);
    const query = els.input.value.trim();
    if (query.length) {
      stopAnimatedPlaceholder();
    } else {
      startAnimatedPlaceholder(true);
    }
    if (query.length < 2) {
      els.results.innerHTML = "";
      setStatus(query.length ? "Digite pelo menos 2 letras." : "Digite o nome de um jogo para comparar preços.");
      return;
    }
    debounceId = setTimeout(() => search(query), 420);
  });

  await prefillFromSteamTab();
}

function startAnimatedPlaceholder(reset = false) {
  if (!els.input) return;
  if (placeholderTimer) clearTimeout(placeholderTimer);

  let gameIndex = reset ? 0 : Number(els.input.dataset.placeholderGameIndex || 0);
  let charIndex = reset ? 0 : Number(els.input.dataset.placeholderCharIndex || 0);
  let deleting = reset ? false : els.input.dataset.placeholderDeleting === "1";

  const tick = () => {
    if (els.input.value.trim()) {
      els.input.placeholder = "";
      placeholderTimer = null;
      return;
    }

    const current = PLACEHOLDER_GAMES[gameIndex % PLACEHOLDER_GAMES.length];
    const visible = current.slice(0, charIndex);
    els.input.placeholder = visible ? `Ex: ${visible}▌` : "Ex: ▌";

    let delay = deleting ? 24 : 42;

    if (!deleting && charIndex < current.length) {
      charIndex += 1;
    } else if (!deleting && charIndex >= current.length) {
      deleting = true;
      delay = 720;
    } else if (deleting && charIndex > 0) {
      charIndex -= 1;
    } else {
      deleting = false;
      gameIndex = (gameIndex + 1) % PLACEHOLDER_GAMES.length;
      delay = 260;
    }

    els.input.dataset.placeholderGameIndex = String(gameIndex);
    els.input.dataset.placeholderCharIndex = String(charIndex);
    els.input.dataset.placeholderDeleting = deleting ? "1" : "0";
    placeholderTimer = setTimeout(tick, delay);
  };

  tick();
}

function stopAnimatedPlaceholder() {
  if (placeholderTimer) clearTimeout(placeholderTimer);
  placeholderTimer = null;
  if (els.input) els.input.placeholder = "";
}

async function loadEffectiveSettings() {
  const stored = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
  if (stored.autoDetectRegion !== false) {
    const detected = detectUserRegion();
    stored.country = detected.country;
    stored.currency = detected.currency;
  }
  return stored;
}

function detectUserRegion() {
  const language = chrome.i18n?.getUILanguage?.() || navigator.language || "pt-BR";
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
  const countryFromLang = (language.match(/[-_]([A-Z]{2})$/i)?.[1] || "").toUpperCase();
  const timeZoneCountry = detectCountryByTimezone(timeZone);
  const country = countryFromLang || timeZoneCountry || "BR";
  return { country, currency: currencyForCountry(country) };
}

function detectCountryByTimezone(timeZone) {
  const tz = String(timeZone).toLowerCase();
  if (tz.includes("sao_paulo") || tz.includes("brasil")) return "BR";
  if (tz.includes("buenos_aires")) return "AR";
  if (tz.includes("santiago")) return "CL";
  if (tz.includes("mexico")) return "MX";
  if (tz.includes("lisbon") || tz.includes("azores") || tz.includes("madeira")) return "PT";
  if (tz.includes("london")) return "GB";
  if (tz.includes("tokyo")) return "JP";
  return "";
}

function currencyForCountry(country) {
  return ({ BR: "BRL", US: "USD", AR: "ARS", CL: "CLP", MX: "MXN", PT: "EUR", GB: "GBP", JP: "JPY", CA: "CAD", AU: "AUD" })[country] || "USD";
}

function updateShortcutBadge() {
  const badge = document.querySelector("#shortcutBadge");
  if (!badge || !chrome.commands?.getAll) return;
  chrome.commands.getAll((commands) => {
    const command = commands.find((item) => item.name === "open-akai-deals");
    badge.textContent = command?.shortcut || "Definir atalho";
    badge.title = command?.shortcut ? "Atalho da extensão" : "Clique para configurar o atalho";
  });
}

async function prefillFromSteamTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.startsWith("https://store.steampowered.com/app/")) return;
    const title = String(tab.title || "").replace(/ no Steam$/i, "").replace(/ on Steam$/i, "").trim();
    if (title && !els.input.value) {
      els.input.value = title;
      search(title);
    }
  } catch {}
}

async function openDashboard(draft = null) {
  if (draft) await chrome.storage.local.set({ dashboardDraftAlert: draft });
  const url = chrome.runtime.getURL("dashboard/dashboard.html");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (chrome.sidePanel?.open && tab?.id) {
      await chrome.sidePanel.open({ tabId: tab.id });
      return;
    }
  } catch {}
  chrome.tabs.create({ url });
}

function updateCounters() {
  const steam = settings.ownedCache?.games?.length || 0;
  const manual = Object.values(settings.manualLibrary || {}).reduce((sum, list) => sum + (Array.isArray(list) ? list.length : 0), 0);
  const wishlist = settings.wishlistCache?.games?.length || 0;
  els.libraryCount.textContent = `Biblioteca: ${steam + manual}`;
  els.wishlistCount.textContent = `Wishlist: ${wishlist}`;
}

async function search(query) {
  const seq = ++requestSeq;
  els.results.innerHTML = "";

  if (!settings.itadApiKey) {
    setStatus("Configure sua API Key do IsThereAnyDeal nas configurações.", "error");
    return;
  }

  setStatus(`Buscando “${query}”...`, "loading");

  const response = await sendMessage({
    type: "searchDeals",
    query,
    options: { drmFilter: els.drmFilter.value, typeFilter: els.typeFilter.value, sortMode: els.sortMode.value, limit: settings.resultsLimit || 12, includeFallback: true }
  });

  if (seq !== requestSeq) return;
  if (!response.ok) {
    setStatus(response.error || "Erro ao buscar preços.", "error");
    return;
  }

  renderResults(response.results || [], query);
  setStatus(response.results?.length ? `${response.results.length} resultado(s). Clique em uma loja para abrir.` : "Nenhum resultado encontrado.");
}

function renderResults(results, query) {
  els.results.innerHTML = "";
  const list = Array.isArray(results) ? results.filter(Boolean) : [];

  for (const item of list) {
    const node = els.resultTpl.content.cloneNode(true);
    node.querySelector(".game-title").textContent = item.title;

    const ownedBadge = node.querySelector(".owned-badge");
    if (item.owned) {
      ownedBadge.textContent = item.ownedSources?.length ? `Já tenho: ${item.ownedSources.join("/")}` : "Já tenho";
      ownedBadge.classList.remove("hidden");
    }

    const coverBox = node.querySelector(".game-cover");
    const coverText = node.querySelector(".game-cover span");
    if (item.image) {
      const img = document.createElement("img");
      img.src = item.image;
      img.alt = "";
      coverBox.innerHTML = "";
      coverBox.append(img);
    } else {
      coverText.textContent = initials(item.title);
    }

    const dealList = node.querySelector(".deal-list");
    const deals = compactDeals(item.deals || []);
    if (deals.length) {
      deals.slice(0, 10).forEach((deal) => dealList.append(renderDeal(deal)));
    } else {
      const fallback = item.buyUrl || item.itadUrl || `https://isthereanydeal.com/search/?q=${encodeURIComponent(query)}`;
      dealList.append(renderFallbackDeal(item.instantFallback ? "Instant Gaming" : "Abrir busca", "Abrir", fallback));
    }

    const itadLink = node.querySelector(".itad-link");
    itadLink.href = item.itadUrl || `https://isthereanydeal.com/search/?q=${encodeURIComponent(item.title)}`;

    els.results.append(node);
  }
}

function compactPopupResults(results, query) {
  const list = Array.isArray(results) ? results.filter(Boolean) : [];
  if (!list.length) return [];

  const q = normalizeTitle(query);
  const exact = list.filter((item) => normalizeTitle(item.title) === q && !item.instantFallback);
  if (exact.length) return exact.slice(0, 3);

  const strong = list.filter((item) => {
    const t = normalizeTitle(item.title);
    return !item.instantFallback && (t.startsWith(q) || q.startsWith(t) || similarity(t, q) > 0.86);
  });
  return (strong.length ? strong : list).slice(0, 5);
}

function compactDeals(deals) {
  const bestByStore = new Map();
  for (const deal of deals || []) {
    if (!deal) continue;
    const shop = deal.shop?.name || "Loja";
    const key = normalizeStoreName(shop);
    const current = bestByStore.get(key);
    if (!current || priceNumber(deal) < priceNumber(current)) bestByStore.set(key, deal);
  }
  return [...bestByStore.values()].sort((a, b) => priceNumber(a) - priceNumber(b));
}

function normalizeStoreName(name) {
  return String(name || "loja").toLowerCase().replace(/[^a-z0-9]+/g, "").trim();
}

function priceNumber(deal) {
  const n = Number(deal?.price?.amount);
  return Number.isFinite(n) ? n : Number.POSITIVE_INFINITY;
}

function renderDeal(deal) {
  const node = els.dealTpl.content.cloneNode(true);
  const a = node.querySelector(".deal-row");
  const shopName = deal.shop?.name || "Loja";
  a.href = deal.url || "#";
  a.title = `${shopName} • ${formatDRM(deal)}`;
  node.querySelector(".store-avatar").textContent = initials(shopName);
  node.querySelector(".store-name").textContent = shopName;
  node.querySelector(".deal-price").textContent = deal.price ? formatMoney(deal.price) : "Buscar";
  return node;
}

function renderFallbackDeal(store, price, url) {
  const node = els.dealTpl.content.cloneNode(true);
  const a = node.querySelector(".deal-row");
  a.href = url;
  node.querySelector(".store-avatar").textContent = initials(store);
  node.querySelector(".store-name").textContent = store;
  node.querySelector(".deal-price").textContent = price;
  return node;
}

function formatDRM(deal) {
  const raw = Array.isArray(deal?.drm) ? deal.drm : [deal?.drm];
  const text = raw.filter(Boolean).join(" / ");
  if (!text) {
    const shop = String(deal?.shop?.name || "").toLowerCase();
    if (shop.includes("gog")) return "GOG";
    if (shop.includes("epic")) return "Epic";
    if (shop.includes("instant")) return "Steam Key";
    return "—";
  }
  if (/steam/i.test(text)) return "Steam Key";
  if (/gog|drm.free|drm free/i.test(text)) return "GOG";
  if (/epic/i.test(text)) return "Epic";
  if (/ubisoft|uplay/i.test(text)) return "Ubisoft";
  if (/origin|ea app|electronic arts/i.test(text)) return "EA";
  return text.replace(/,/g, " / ").slice(0, 24);
}

function initials(text) {
  const clean = String(text || "AD").replace(/[^a-zA-Z0-9À-ÿ ]/g, " ").trim();
  const parts = clean.split(/\s+/).filter(Boolean);
  if (!parts.length) return "AD";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
}

function tag(text, cls) {
  const el = document.createElement("span");
  el.className = `tag ${cls || ""}`.trim();
  el.textContent = text;
  return el;
}

function labelType(value) {
  const raw = String(value || "").toLowerCase();
  if (raw === "game" || raw.includes("jogo")) return "Jogo";
  if (raw === "dlc" || raw.includes("downloadable")) return "DLC";
  if (raw === "all") return "Jogo + DLC";
  if (raw.includes("package")) return "Pacote";
  if (raw.includes("search")) return "Busca";
  return "Tipo indef.";
}

function formatMoney(price) {
  if (!price || price.amount === undefined || price.amount === null) return "—";
  const currency = price.currency || settings.currency || "BRL";
  try { return new Intl.NumberFormat("pt-BR", { style: "currency", currency }).format(Number(price.amount)); }
  catch { return `${currency} ${Number(price.amount).toFixed(2)}`; }
}


function normalizeTitle(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\b(complete|edition|deluxe|ultimate|goty|game of the year|remaster|remastered|definitive)\b/g, "")
    .trim();
}

function similarity(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const longer = a.length > b.length ? a : b;
  const shorter = a.length > b.length ? b : a;
  if (!longer.length) return 1;
  return (longer.length - levenshtein(longer, shorter)) / longer.length;
}

function levenshtein(a, b) {
  const matrix = Array.from({ length: b.length + 1 }, (_, i) => [i]);
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      matrix[i][j] = b.charAt(i - 1) === a.charAt(j - 1)
        ? matrix[i - 1][j - 1]
        : Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
    }
  }
  return matrix[b.length][a.length];
}

function sendMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(payload, (response) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve(response || { ok: false, error: "Sem resposta." });
    });
  });
}

function setStatus(message, type = "") {
  els.status.className = `status ${type}`.trim();
  els.status.textContent = message;
}
