const DEFAULT_SETTINGS = {
  itadApiKey: "",
  country: "BR",
  currency: "BRL",
  autoDetectRegion: true,
  resultsLimit: 12,
  drmFilter: "all",
  typeFilter: "game",
  sortMode: "popular",
  steamApiKey: "",
  steamId64: "",
  instantGamingEnabled: true,
  instantGamingApiBase: "",
  instantGamingLatamPriority: true,
  compareOnSteam: true,
  notificationsEnabled: true,
  ownedCache: null,
  ownedCacheUpdatedAt: 0,
  wishlistCache: null,
  wishlistCacheUpdatedAt: 0,
  manualLibrary: { gog: [], epic: [], other: [] },
  priceAlerts: [],
  notificationLinks: {}
};

const fields = {
  itadApiKey: document.querySelector("#itadApiKey"),
  country: document.querySelector("#country"),
  currency: document.querySelector("#currency"),
  autoDetectRegion: document.querySelector("#autoDetectRegion"),
  resultsLimit: document.querySelector("#resultsLimit"),
  drmFilter: document.querySelector("#drmFilter"),
  sortMode: document.querySelector("#sortMode"),
  typeFilter: document.querySelector("#typeFilter"),
  steamApiKey: document.querySelector("#steamApiKey"),
  steamId64: document.querySelector("#steamId64"),
  instantGamingEnabled: document.querySelector("#instantGamingEnabled"),
  instantGamingApiBase: document.querySelector("#instantGamingApiBase"),
  instantGamingLatamPriority: document.querySelector("#instantGamingLatamPriority"),
  compareOnSteam: document.querySelector("#compareOnSteam"),
  notificationsEnabled: document.querySelector("#notificationsEnabled"),
  gogLibrary: document.querySelector("#gogLibrary"),
  epicLibrary: document.querySelector("#epicLibrary"),
  otherLibrary: document.querySelector("#otherLibrary")
};

const form = document.querySelector("#settingsForm");
const saveStatus = document.querySelector("#saveStatus");
const steamStatus = document.querySelector("#steamStatus");
const alertStatus = document.querySelector("#alertStatus");

init();

async function init() {
  const settings = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
  setForm(settings);
  updateCurrentShortcut();

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const next = readForm();
    await chrome.storage.local.set(next);
    setSaveStatus("Salvo.");
  });

  document.querySelector("#reset").addEventListener("click", async () => {
    await chrome.storage.local.set(DEFAULT_SETTINGS);
    setForm(DEFAULT_SETTINGS);
    setSaveStatus("Resetado.");
  });

  document.querySelector("#syncSteam").addEventListener("click", syncSteam);
  document.querySelector("#syncWishlist").addEventListener("click", syncWishlist);
  document.querySelector("#checkAlerts").addEventListener("click", checkAlertsNow);
  document.querySelector("#openDashboard").addEventListener("click", openDashboard);
  document.querySelector("#openShortcutsText").addEventListener("click", (event) => { event.preventDefault(); chrome.tabs.create({ url: "chrome://extensions/shortcuts" }); });
  fields.autoDetectRegion.addEventListener("change", updateRegionFieldsState);

  document.querySelectorAll(".link-btn[data-url]").forEach((button) => {
    button.addEventListener("click", () => chrome.tabs.create({ url: button.dataset.url }));
  });
}

function setForm(settings) {
  fields.itadApiKey.value = settings.itadApiKey || "";
  fields.country.value = settings.country || "BR";
  fields.currency.value = settings.currency || "BRL";
  fields.autoDetectRegion.checked = settings.autoDetectRegion !== false;
  updateRegionFieldsState();
  fields.resultsLimit.value = settings.resultsLimit || 12;
  fields.drmFilter.value = settings.drmFilter || "all";
  fields.sortMode.value = settings.sortMode || "popular";
  fields.typeFilter.value = settings.typeFilter || "game";
  fields.steamApiKey.value = settings.steamApiKey || "";
  fields.steamId64.value = settings.steamId64 || "";
  fields.instantGamingEnabled.checked = Boolean(settings.instantGamingEnabled);
  fields.instantGamingApiBase.value = settings.instantGamingApiBase || "";
  fields.instantGamingLatamPriority.checked = Boolean(settings.instantGamingLatamPriority);
  fields.compareOnSteam.checked = settings.compareOnSteam !== false;
  fields.notificationsEnabled.checked = settings.notificationsEnabled !== false;
  fields.gogLibrary.value = (settings.manualLibrary?.gog || []).join("\n");
  fields.epicLibrary.value = (settings.manualLibrary?.epic || []).join("\n");
  fields.otherLibrary.value = (settings.manualLibrary?.other || []).join("\n");
}

function updateRegionFieldsState() {
  const auto = fields.autoDetectRegion?.checked;
  fields.country.disabled = Boolean(auto);
  fields.currency.disabled = Boolean(auto);
}

function readForm() {
  return {
    itadApiKey: fields.itadApiKey.value.trim(),
    country: fields.country.value,
    currency: fields.currency.value,
    autoDetectRegion: fields.autoDetectRegion.checked,
    resultsLimit: Math.min(40, Math.max(1, Number(fields.resultsLimit.value || 12))),
    drmFilter: fields.drmFilter.value,
    sortMode: fields.sortMode.value,
    typeFilter: fields.typeFilter.value,
    steamApiKey: fields.steamApiKey.value.trim(),
    steamId64: fields.steamId64.value.trim(),
    instantGamingEnabled: fields.instantGamingEnabled.checked,
    instantGamingApiBase: fields.instantGamingApiBase.value.trim().replace(/\/$/, ""),
    instantGamingLatamPriority: fields.instantGamingLatamPriority.checked,
    compareOnSteam: fields.compareOnSteam.checked,
    notificationsEnabled: fields.notificationsEnabled.checked,
    manualLibrary: {
      gog: parseLines(fields.gogLibrary.value),
      epic: parseLines(fields.epicLibrary.value),
      other: parseLines(fields.otherLibrary.value)
    }
  };
}

async function syncSteam() {
  const settings = readForm();
  await chrome.storage.local.set(settings);

  if (!settings.steamApiKey || !settings.steamId64) {
    steamStatus.textContent = "Preencha Steam API Key e SteamID64 primeiro.";
    return;
  }

  steamStatus.textContent = "Atualizando biblioteca Steam...";
  try {
    const url = new URL("https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/");
    url.searchParams.set("key", settings.steamApiKey);
    url.searchParams.set("steamid", settings.steamId64);
    url.searchParams.set("include_appinfo", "true");
    url.searchParams.set("format", "json");

    const response = await fetch(url.toString());
    if (!response.ok) throw new Error(`Erro ${response.status}`);
    const data = await readJson(response);
    const games = data?.response?.games || [];
    const names = games.map((game) => game.name).filter(Boolean).sort((a, b) => a.localeCompare(b));

    await chrome.storage.local.set({
      ...settings,
      ownedCache: { games: names },
      ownedCacheUpdatedAt: Date.now()
    });

    steamStatus.textContent = `Biblioteca atualizada: ${names.length} jogo(s).`;
    setSaveStatus("Configurações e biblioteca salvas.");
  } catch (error) {
    console.error(error);
    steamStatus.textContent = "Não consegui ler a biblioteca. Confira key, SteamID64 e privacidade do perfil.";
  }
}

async function syncWishlist() {
  const settings = readForm();
  await chrome.storage.local.set(settings);

  if (!settings.steamId64) {
    steamStatus.textContent = "Preencha o SteamID64 para importar a wishlist.";
    return;
  }

  steamStatus.textContent = "Importando wishlist Steam...";
  try {
    const games = [];
    for (let page = 0; page < 25; page++) {
      const url = `https://store.steampowered.com/wishlist/profiles/${encodeURIComponent(settings.steamId64)}/wishlistdata/?p=${page}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Erro ${response.status}`);
      const data = await readJson(response);
      const items = Object.entries(data || {}).map(([appid, item]) => ({
        appid,
        name: item.name || item.title || `App ${appid}`,
        url: `https://store.steampowered.com/app/${appid}/`
      }));
      if (!items.length) break;
      games.push(...items);
      if (items.length < 100) break;
    }

    const unique = Array.from(new Map(games.map((game) => [game.appid, game])).values())
      .sort((a, b) => a.name.localeCompare(b.name));

    await chrome.storage.local.set({
      ...settings,
      wishlistCache: { games: unique },
      wishlistCacheUpdatedAt: Date.now()
    });

    steamStatus.textContent = `Wishlist importada: ${unique.length} jogo(s).`;
    setSaveStatus("Configurações e wishlist salvas.");
  } catch (error) {
    console.error(error);
    steamStatus.textContent = "Não consegui importar a wishlist. Confira se ela está pública/acessível.";
  }
}

async function checkAlertsNow() {
  alertStatus.textContent = "Verificando alertas...";
  const response = await sendMessage({ type: "checkAlertsNow" });
  alertStatus.textContent = response.ok
    ? `Alertas verificados: ${(response.updated || []).length}.`
    : (response.error || "Erro ao verificar alertas.");
}

async function openDashboard() {
  const url = chrome.runtime.getURL("dashboard/dashboard.html");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (chrome.sidePanel?.open && tab?.id) {
      await chrome.sidePanel.open({ tabId: tab.id });
      return;
    }
  } catch {}
  chrome.tabs.create({ url });
}

async function readJson(response) {
  const text = await response.text();
  try {
    return text ? JSON.parse(text) : null;
  } catch {
    if (/^\s*</.test(text)) throw new Error("A Steam devolveu HTML em vez de JSON. Veja se o perfil/wishlist está público ou se a URL está acessível.");
    throw new Error("Resposta inválida: não é JSON.");
  }
}

function parseLines(value) {
  return Array.from(new Set(String(value || "")
    .split(/\r?\n|;/)
    .map((line) => line.trim())
    .filter(Boolean)))
    .sort((a, b) => a.localeCompare(b));
}

function sendMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(payload, (response) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve(response || { ok: false, error: "Sem resposta." });
    });
  });
}

function setSaveStatus(text) {
  saveStatus.textContent = text;
  setTimeout(() => { saveStatus.textContent = ""; }, 3000);
}

function updateCurrentShortcut() {
  const el = document.querySelector("#currentShortcut");
  if (!el || !chrome.commands?.getAll) return;
  chrome.commands.getAll((commands) => {
    const command = commands.find((item) => item.name === "open-akai-deals");
    el.textContent = command?.shortcut || "não definido";
  });
}
