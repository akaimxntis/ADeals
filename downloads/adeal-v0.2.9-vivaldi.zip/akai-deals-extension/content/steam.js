(function () {
  if (window.__akaiDealsInjected) return;
  window.__akaiDealsInjected = true;

  let pageInfo = null;
  let box = null;
  let attempts = 0;

  boot();

  function boot() {
    pageInfo = getStorePageInfo();
    if (!pageInfo?.title || !isLikelyProductPage(pageInfo)) {
      if (attempts++ < 20) setTimeout(boot, 300);
      return;
    }
    createBox();
  }

  function createBox() {
    box = document.createElement("aside");
    box.id = "akai-deals-steam-box";
    box.innerHTML = `
      <div class="akai-head">
        <div class="akai-title-wrap">
          <span>Akai Deals</span>
          <strong>${escapeHtml(pageInfo.store || "Comparador")}</strong>
        </div>
        <button class="akai-close" title="Fechar">×</button>
      </div>
      <div class="akai-body">
        <div class="akai-loading">Buscando ofertas...</div>
        <div class="akai-search-title"></div>
      </div>
    `;
    box.querySelector(".akai-search-title").textContent = pageInfo.title;
    document.documentElement.appendChild(box);
    box.querySelector(".akai-close").addEventListener("click", () => box.remove());

    chrome.runtime.sendMessage({ type: "compareTitle", title: pageInfo.title, typeFilter: pageInfo.typeFilter || "game" }, (response) => {
      if (chrome.runtime.lastError) return renderError(chrome.runtime.lastError.message);
      if (!response?.ok) return renderError(response?.error || "Erro ao comparar.");
      if (response.disabled) return box.remove();
      renderResults(response.results || []);
    });
  }

  function renderResults(results) {
    const body = box.querySelector(".akai-body");
    if (!results.length) {
      body.innerHTML = `<div class="akai-empty">Nenhuma oferta encontrada.</div><div class="akai-search-title">${escapeHtml(pageInfo.title)}</div>`;
      return;
    }

    const best = chooseBestMatch(results, pageInfo.title);
    const offers = compactOffers(best).slice(0, 6);
    const bestPrice = offers[0]?.priceText || (best.current ? formatMoney(best.current.price) : "Abrir busca");
    const bestUrl = offers[0]?.url || best.buyUrl || best.itadUrl || "#";

    body.innerHTML = `
      <div class="akai-game-row">
        <div class="akai-game-name" title="${escapeAttr(best.title || pageInfo.title)}">${escapeHtml(best.title || pageInfo.title)}</div>
        <a class="akai-best-pill" href="${escapeAttr(bestUrl)}" target="_blank" rel="noreferrer">${escapeHtml(bestPrice)}</a>
      </div>
      <div class="akai-offer-list">
        ${offers.length ? offers.map(renderOffer).join("") : `<a class="akai-offer-row" href="${escapeAttr(best.buyUrl || best.itadUrl || "#")}" target="_blank" rel="noreferrer"><span>Abrir busca</span><strong>↗</strong></a>`}
      </div>
      <div class="akai-footer-row">
        ${best.owned ? `<span>✅ Já tenho</span>` : ""}
        ${best.wishlisted ? `<span>⭐ Wishlist</span>` : ""}
        ${best.lowest ? `<span>Histórico: ${escapeHtml(formatMoney(best.lowest.price))}</span>` : ""}
      </div>
    `;
  }

  function renderOffer(offer) {
    const drm = offer.drmText ? `<em>${escapeHtml(offer.drmText)}</em>` : "";
    return `
      <a class="akai-offer-row" href="${escapeAttr(offer.url || "#")}" target="_blank" rel="noreferrer" title="${escapeAttr(offer.shop)}">
        <span>${escapeHtml(offer.shop)}${drm}</span>
        <strong>${escapeHtml(offer.priceText)}</strong>
      </a>
    `;
  }

  function compactOffers(game) {
    const raw = [];
    if (game.current) raw.push(game.current);
    if (Array.isArray(game.deals)) raw.push(...game.deals);

    const byShop = new Map();
    for (const deal of raw) {
      if (!deal) continue;
      const shop = deal.shop?.name || deal.shopName || "Loja";
      const priceAmount = deal.price?.amount;
      const priceText = formatMoney(deal.price);
      const key = shop.toLowerCase().trim();
      const next = {
        shop,
        priceText,
        priceAmount: Number.isFinite(Number(priceAmount)) ? Number(priceAmount) : Number.POSITIVE_INFINITY,
        url: localizeUrl(deal.url || game.buyUrl || game.itadUrl || "#"),
        drmText: shortDrm(deal)
      };
      const current = byShop.get(key);
      if (!current || next.priceAmount < current.priceAmount) byShop.set(key, next);
    }

    return [...byShop.values()].sort((a, b) => a.priceAmount - b.priceAmount || a.shop.localeCompare(b.shop));
  }

  function chooseBestMatch(results, wanted) {
    const normalizedWanted = normalizeTitle(wanted);
    const exact = results.find((item) => normalizeTitle(item.title) === normalizedWanted);
    if (exact) return exact;
    const close = [...results].sort((a, b) => similarity(normalizeTitle(b.title), normalizedWanted) - similarity(normalizeTitle(a.title), normalizedWanted))[0];
    return close || results[0];
  }

  function getStorePageInfo() {
    const host = location.hostname.replace(/^www\./, "").toLowerCase();
    const path = location.pathname;
    const metaTitle = cleanTitle(document.querySelector("meta[property='og:title']")?.content || document.querySelector("meta[name='twitter:title']")?.content || document.title);
    const h1 = cleanTitle(document.querySelector("h1")?.textContent || "");

    const steamTitle = document.querySelector(".apphub_AppName")?.textContent?.trim()
      || document.querySelector("#appHubAppName")?.textContent?.trim();

    const selectors = [
      ".productcard-basics__title",
      "[data-testid='product-title']",
      "[data-testid='pdp-title']",
      ".css-1ufjsin",
      ".product-title",
      ".product-hero__title",
      ".pdp-title",
      ".game-title",
      ".product-name",
      ".product-details h1"
    ];
    const selected = selectors.map((sel) => document.querySelector(sel)?.textContent?.trim()).find(Boolean);

    let store = "Loja";
    if (host.includes("steampowered.com")) store = "Steam";
    else if (host.includes("gog.com")) store = "GOG";
    else if (host.includes("epicgames.com")) store = "Epic";
    else if (host.includes("nuuvem.com")) store = "Nuuvem";
    else if (host.includes("fanatical.com")) store = "Fanatical";
    else if (host.includes("greenmangaming.com")) store = "Green Man Gaming";
    else if (host.includes("humblebundle.com")) store = "Humble Store";
    else if (host.includes("gamersgate.com")) store = "GamersGate";
    else if (host.includes("instant-gaming.com")) store = "Instant Gaming";

    const title = cleanTitle(steamTitle || selected || h1 || metaTitle);
    return {
      host,
      path,
      store,
      title,
      typeFilter: inferTypeFilter(title, path)
    };
  }

  function isLikelyProductPage(info) {
    const host = info.host;
    const path = info.path.toLowerCase();
    if (!info.title || info.title.length < 2) return false;
    if (/^(store|home|search|deals|sale|wishlist|library|cart|checkout|login|sign in)$/i.test(info.title)) return false;
    if (host.includes("steampowered.com")) return /^\/app\/\d+/.test(path);
    if (host.includes("gog.com")) return /^\/game\//.test(path) || /^\/[a-z]{2}\/game\//.test(path);
    if (host.includes("epicgames.com")) return path.includes("/p/") || path.includes("/product/") || path.includes("/bundles/");
    if (host.includes("nuuvem.com")) return path.includes("/item/") || path.includes("/product") || path.includes("/bundle");
    if (host.includes("fanatical.com")) return path.includes("/game/") || path.includes("/bundle/") || path.includes("/dlc/");
    if (host.includes("greenmangaming.com")) return path.includes("/games/") || path.includes("/software/");
    if (host.includes("humblebundle.com")) return path.includes("/store/");
    if (host.includes("gamersgate.com")) return path.includes("/product/") || path.includes("/games/");
    if (host.includes("instant-gaming.com")) return /-\d+/.test(path) || path.includes("/pt/") || path.includes("/en/");
    return false;
  }

  function inferTypeFilter(title, path) {
    const text = `${title || ""} ${path || ""}`.toLowerCase();
    if (/\b(dlc|season-pass|season pass|expansion|add-on|add on|chapter|episode)\b/i.test(text)) return "dlc";
    return "game";
  }

  function cleanTitle(value) {
    return String(value || "")
      .replace(/\s+on Steam$/i, "")
      .replace(/\s+no Steam$/i, "")
      .replace(/\s*[|–—-]\s*(Steam|GOG\.com|Epic Games Store|Nuuvem|Fanatical|Green Man Gaming|Humble Store|GamersGate|Instant Gaming).*$/i, "")
      .replace(/\s+\(PC\s*\/?.*?\)$/i, "")
      .replace(/\s+PC Game$/i, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function shortDrm(deal) {
    const text = [
      deal?.shop?.name,
      deal?.url,
      ...(Array.isArray(deal?.drm) ? deal.drm : [deal?.drm])
    ].filter(Boolean).join(" ").toLowerCase();

    if (text.includes("gog") || text.includes("drm-free") || text.includes("drm free")) return "GOG";
    if (text.includes("epic")) return "Epic";
    if (text.includes("ubisoft") || text.includes("uplay")) return "Ubisoft";
    if (text.includes("ea app") || text.includes("origin")) return "EA";
    if (text.includes("steam")) return "Steam";
    return "";
  }

  function localizeUrl(url) {
    if (!url || url === "#") return url;
    try {
      const parsed = new URL(url, location.href);
      const locale = navigator.language || "pt-BR";
      const country = (locale.split("-")[1] || "BR").toUpperCase();
      if (parsed.hostname.includes("store.steampowered.com") && !parsed.searchParams.has("cc")) {
        parsed.searchParams.set("cc", country);
      }
      return parsed.toString();
    } catch {
      return url;
    }
  }

  function renderError(message) {
    box.querySelector(".akai-body").innerHTML = `<span class="akai-error">${escapeHtml(message || "Erro")}</span>`;
  }

  function formatMoney(price) {
    if (!price || price.amount === undefined || price.amount === null) return "—";
    try { return new Intl.NumberFormat("pt-BR", { style: "currency", currency: price.currency || "BRL" }).format(Number(price.amount)); }
    catch { return `${price.currency || ""} ${Number(price.amount).toFixed(2)}`; }
  }

  function normalizeTitle(value) {
    return String(value || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, " ")
      .replace(/\b(complete|edition|deluxe|ultimate|goty|game of the year|remaster|remastered|definitive|enhanced|director s cut)\b/g, "")
      .trim();
  }

  function similarity(a, b) {
    if (!a || !b) return 0;
    if (a === b) return 1;
    const longer = a.length > b.length ? a : b;
    const shorter = a.length > b.length ? b : a;
    if (!longer.length) return 1;
    return (longer.length - levenshtein(longer, shorter)) / longer.length;
  }

  function levenshtein(a, b) {
    const matrix = Array.from({ length: b.length + 1 }, (_, i) => [i]);
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        matrix[i][j] = b.charAt(i - 1) === a.charAt(j - 1)
          ? matrix[i - 1][j - 1]
          : Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
      }
    }
    return matrix[b.length][a.length];
  }

  function escapeHtml(value) {
    return String(value || "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, "&#96;");
  }
})();
