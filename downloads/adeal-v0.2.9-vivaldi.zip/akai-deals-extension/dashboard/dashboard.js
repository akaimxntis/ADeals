const DEFAULT_SETTINGS = {
  ownedCache: null,
  wishlistCache: null,
  manualLibrary: { gog: [], epic: [], other: [] },
  priceAlerts: [],
  currency: "BRL",
  resultsLimit: 12,
  drmFilter: "all",
  typeFilter: "game",
  sortMode: "popular",
  dashboardDraftAlert: null
};

const els = {
  ownedCount: document.querySelector("#ownedCount"),
  wishlistCount: document.querySelector("#wishlistCount"),
  alertCount: document.querySelector("#alertCount"),
  alertsList: document.querySelector("#alertsList"),
  wishlistList: document.querySelector("#wishlistList"),
  manualList: document.querySelector("#manualList"),
  wishlistFilter: document.querySelector("#wishlistFilter"),
  searchInput: document.querySelector("#searchInput"),
  searchBtn: document.querySelector("#searchBtn"),
  searchStatus: document.querySelector("#searchStatus"),
  searchResults: document.querySelector("#searchResults"),
  drmFilter: document.querySelector("#drmFilter"),
  typeFilter: document.querySelector("#typeFilter"),
  sortMode: document.querySelector("#sortMode"),
  checkAlerts: document.querySelector("#checkAlerts"),
  openOptions: document.querySelector("#openOptions"),
  alertTitle: document.querySelector("#alertTitle"),
  alertTarget: document.querySelector("#alertTarget"),
  alertCurrency: document.querySelector("#alertCurrency"),
  createAlert: document.querySelector("#createAlert"),
  createAlertStatus: document.querySelector("#createAlertStatus")
};

let settings = { ...DEFAULT_SETTINGS };
let debounceId = null;

init();

async function init() {
  await refresh();
  chrome.storage.onChanged.addListener(refresh);
  els.openOptions.addEventListener("click", () => chrome.runtime.openOptionsPage());
  els.checkAlerts.addEventListener("click", checkAlerts);
  els.createAlert.addEventListener("click", createAlertFromDashboard);
  els.searchBtn.addEventListener("click", () => searchNow());
  els.drmFilter.value = settings.drmFilter || "all";
  els.typeFilter.value = settings.typeFilter || "game";
  els.sortMode.value = settings.sortMode || "popular";
  els.drmFilter.addEventListener("change", () => searchNow());
  els.typeFilter.addEventListener("change", () => searchNow());
  els.sortMode.addEventListener("change", () => searchNow());
  els.searchInput.addEventListener("input", () => {
    clearTimeout(debounceId);
    debounceId = setTimeout(searchNow, 450);
  });
  els.wishlistFilter.addEventListener("input", renderWishlist);
  await loadDraftAlert();
}

async function refresh() {
  settings = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
  if (els.drmFilter) els.drmFilter.value = settings.drmFilter || "all";
  if (els.typeFilter) els.typeFilter.value = settings.typeFilter || "game";
  if (els.sortMode) els.sortMode.value = settings.sortMode || "popular";
  renderStats();
  renderAlerts();
  renderWishlist();
  renderManual();
  if (settings.dashboardDraftAlert?.title) await loadDraftAlert();
}

async function loadDraftAlert() {
  const draft = settings.dashboardDraftAlert;
  if (!draft || !draft.title) {
    if (els.alertCurrency && !els.alertCurrency.value) els.alertCurrency.value = settings.currency || "BRL";
    return;
  }
  els.alertTitle.value = draft.title || "";
  els.alertCurrency.value = draft.currency || settings.currency || "BRL";
  if (draft.currentPrice) {
    const suggested = Math.max(1, Math.floor(Number(draft.currentPrice) * 0.75));
    els.alertTarget.value = String(suggested);
    els.createAlertStatus.textContent = `Rascunho vindo do popup: ${draft.currentShop || "melhor preço atual"}.`;
  } else {
    els.createAlertStatus.textContent = "Rascunho vindo do popup. Defina o preço alvo.";
  }
  await chrome.storage.local.remove("dashboardDraftAlert");
}

async function createAlertFromDashboard() {
  const title = els.alertTitle.value.trim();
  const target = Number(String(els.alertTarget.value).replace(",", "."));
  const currency = (els.alertCurrency.value.trim() || settings.currency || "BRL").toUpperCase();
  if (!title || !Number.isFinite(target) || target <= 0) {
    els.createAlertStatus.textContent = "Preencha o jogo e um preço alvo válido.";
    return;
  }
  els.createAlert.disabled = true;
  els.createAlert.textContent = "Criando...";
  const resp = await sendMessage({
    type: "createAlert",
    alert: {
      title,
      target,
      currency,
      drmFilter: els.drmFilter.value || settings.drmFilter || "all",
      typeFilter: els.typeFilter.value || settings.typeFilter || "game"
    }
  });
  els.createAlert.disabled = false;
  els.createAlert.textContent = "Criar aviso";
  if (!resp.ok) {
    els.createAlertStatus.textContent = resp.error || "Erro ao criar aviso.";
    return;
  }
  els.createAlertStatus.textContent = "Aviso criado.";
  els.alertTarget.value = "";
  await refresh();
}

function renderStats() {
  const steam = settings.ownedCache?.games?.length || 0;
  const manual = Object.values(settings.manualLibrary || {}).reduce((sum, list) => sum + (Array.isArray(list) ? list.length : 0), 0);
  els.ownedCount.textContent = String(steam + manual);
  els.wishlistCount.textContent = String(settings.wishlistCache?.games?.length || 0);
  els.alertCount.textContent = String((settings.priceAlerts || []).length);
}

function renderAlerts() {
  const alerts = settings.priceAlerts || [];
  els.alertsList.innerHTML = "";
  if (!alerts.length) {
    els.alertsList.innerHTML = `<p class="empty">Nenhum alerta criado ainda. Crie pela barra lateral acima.</p>`;
    return;
  }

  alerts.forEach((alert) => {
    const item = document.createElement("article");
    item.className = `item ${alert.enabled ? "" : "disabled"}`;
    const last = alert.lastPrice ? formatMoney({ amount: alert.lastPrice, currency: alert.currency || settings.currency }) : "Ainda não verificado";
    const target = formatMoney({ amount: alert.target, currency: alert.currency || settings.currency });
    item.innerHTML = `
      <div class="item-top">
        <div>
          <p class="title">${escapeHtml(alert.title)}</p>
          <div class="meta">Alvo: <span class="price">${target}</span><br>Último: ${last} ${alert.lastShop ? `em ${escapeHtml(alert.lastShop)}` : ""}<br>DRM: ${labelDRM(alert.drmFilter || "all")}</div>
        </div>
        <input class="toggle" type="checkbox" ${alert.enabled ? "checked" : ""} title="Ativar/desativar" />
      </div>
      <div class="item-actions">
        ${alert.lastUrl ? `<a href="${escapeHtml(alert.lastUrl)}" target="_blank" rel="noreferrer">Abrir</a>` : ""}
        <button class="ghost remove">Remover</button>
      </div>
    `;
    item.querySelector(".toggle").addEventListener("change", async (event) => updateAlert(alert.id, { enabled: event.target.checked }));
    item.querySelector(".remove").addEventListener("click", async () => removeAlert(alert.id));
    els.alertsList.append(item);
  });
}

function renderWishlist() {
  const filter = normalize(els.wishlistFilter.value || "");
  const games = (settings.wishlistCache?.games || []).filter((game) => !filter || normalize(game.name).includes(filter));
  els.wishlistList.innerHTML = "";
  if (!games.length) {
    els.wishlistList.innerHTML = `<p class="empty">Wishlist vazia ou não importada.</p>`;
    return;
  }
  games.slice(0, 80).forEach((game) => {
    const row = document.createElement("a");
    row.className = "item";
    row.href = game.url || `https://store.steampowered.com/app/${game.appid}/`;
    row.target = "_blank";
    row.rel = "noreferrer";
    row.innerHTML = `<p class="title">${escapeHtml(game.name)}</p><div class="meta">Steam App ${escapeHtml(game.appid || "")}</div>`;
    els.wishlistList.append(row);
  });
}

function renderManual() {
  const manual = settings.manualLibrary || {};
  const entries = [
    ["GOG", manual.gog || []],
    ["Epic", manual.epic || []],
    ["Outros", manual.other || []]
  ];
  els.manualList.innerHTML = "";
  entries.forEach(([label, list]) => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.textContent = `${label}: ${list.length}`;
    els.manualList.append(chip);
  });
}

async function searchNow() {
  const query = els.searchInput.value.trim();
  if (query.length < 2) return;
  els.searchStatus.textContent = `Buscando “${query}”...`;
  const resp = await sendMessage({ type: "searchDeals", query, options: { includeFallback: true, limit: settings.resultsLimit || 12, drmFilter: els.drmFilter.value, typeFilter: els.typeFilter.value, sortMode: els.sortMode.value } });
  if (!resp.ok) {
    els.searchStatus.textContent = resp.error || "Erro na busca.";
    return;
  }
  els.searchStatus.textContent = `${(resp.results || []).length} resultado(s).`;
  els.searchResults.innerHTML = "";
  (resp.results || []).forEach((game) => {
    const card = document.createElement("article");
    card.className = "item";
    card.innerHTML = `
      <p class="title">${escapeHtml(game.title)}</p>
      <div class="meta">Melhor: <span class="price">${game.current ? formatMoney(game.current.price) : "Abrir busca"}</span> ${game.current?.shop?.name ? `em ${escapeHtml(game.current.shop.name)}` : ""}<br>Tipo: ${labelType(game.type)}<br>${game.owned ? "✅ Já tenho " : ""}${game.wishlisted ? "⭐ Wishlist" : ""}</div>
      <div class="item-actions"><a href="${escapeHtml(game.buyUrl || game.itadUrl || "#")}" target="_blank" rel="noreferrer">Abrir</a><button class="ghost make-alert">Criar aviso</button></div>
    `;
    card.querySelector(".make-alert").addEventListener("click", () => {
      els.alertTitle.value = game.title || "";
      els.alertCurrency.value = game.current?.price?.currency || settings.currency || "BRL";
      els.alertTarget.value = game.current?.price?.amount ? String(Math.max(1, Math.floor(Number(game.current.price.amount) * 0.75))) : "";
      els.createAlertStatus.textContent = "Jogo carregado da busca. Ajuste o preço alvo e crie o aviso.";
      els.alertTitle.scrollIntoView({ block: "center", behavior: "smooth" });
    });
    els.searchResults.append(card);
  });
}

async function checkAlerts() {
  els.checkAlerts.textContent = "Verificando...";
  const resp = await sendMessage({ type: "checkAlertsNow" });
  els.checkAlerts.textContent = "Verificar";
  await refresh();
  if (!resp.ok) alert(resp.error || "Erro ao verificar alertas.");
}

async function updateAlert(id, patch) {
  const priceAlerts = (settings.priceAlerts || []).map((alert) => alert.id === id ? { ...alert, ...patch } : alert);
  await chrome.storage.local.set({ priceAlerts });
}

async function removeAlert(id) {
  const priceAlerts = (settings.priceAlerts || []).filter((alert) => alert.id !== id);
  await chrome.storage.local.set({ priceAlerts });
}

function sendMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(payload, (response) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve(response || { ok: false, error: "Sem resposta." });
    });
  });
}

function labelDRM(value) {
  return ({ all: "Todos", steam: "Steam Key", gog: "GOG", epic: "Epic", ubisoft: "Ubisoft", ea: "EA", drmfree: "DRM-free", keyshop: "Keyshops" })[value] || value;
}

function labelType(value) {
  const raw = String(value || "").toLowerCase();
  if (raw === "game") return "Jogo";
  if (raw === "dlc") return "DLC";
  if (raw.includes("package")) return "Pacote";
  if (raw.includes("search")) return "Busca";
  return "Tipo indef.";
}

function formatMoney(price) {
  if (!price || price.amount === undefined || price.amount === null) return "—";
  const currency = price.currency || settings.currency || "BRL";
  try { return new Intl.NumberFormat("pt-BR", { style: "currency", currency }).format(Number(price.amount)); }
  catch { return `${currency} ${Number(price.amount).toFixed(2)}`; }
}

function normalize(value) {
  return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function escapeHtml(value) {
  return String(value || "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
}
